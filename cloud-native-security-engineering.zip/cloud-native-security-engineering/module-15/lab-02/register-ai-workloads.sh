#!/bin/bash
set -e
for agent in customer-support code-review data-analyst; do
  spire-server entry create \
    -spiffeID "spiffe://ai.company.org/agent/$agent" \
    -parentID spiffe://ai.company.org/agent \
    -selector "docker:label:app:ai-$agent"
done
echo "✓ AI agent identities registered"
