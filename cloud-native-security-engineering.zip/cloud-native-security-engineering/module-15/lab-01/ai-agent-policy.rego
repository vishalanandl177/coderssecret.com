package ai_authz

default allow = false

allow if {
    input.source_spiffe_id == "spiffe://ai.company.org/agent/customer-support"
    input.target == "/v1/chat/completions"
    input.method == "POST"
}

allow if {
    input.source_spiffe_id == "spiffe://ai.company.org/agent/customer-support"
    input.target_service == "vectordb"
    input.method == "GET"
}

deny[msg] if {
    input.source_spiffe_id == "spiffe://ai.company.org/agent/customer-support"
    input.target_service == "vectordb"
    input.method == "POST"
    msg := "Support agents cannot write to vector DB"
}
