# Module 15 — AI Infrastructure Security
## Labs
- [lab-01: Secure AI Agent Communication](./lab-01)
- [lab-02: Identity-Aware AI API Access](./lab-02)
