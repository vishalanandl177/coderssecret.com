# Lab 1 — Configure OIDC Authentication
Deploy Dex as OIDC provider, configure API server, authenticate with OIDC.
```bash
./setup-dex.sh
kubectl --token=$OIDC_TOKEN get pods
```
