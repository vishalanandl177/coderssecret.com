#!/bin/bash
echo "=== Check who you are ==="
kubectl auth whoami 2>/dev/null || kubectl auth can-i --list
echo
echo "=== Test specific permissions ==="
SA=${1:-default}
NS=${2:-default}
for verb in get list create delete; do
  for resource in pods secrets deployments; do
    RESULT=$(kubectl auth can-i $verb $resource --as=system:serviceaccount:$NS:$SA 2>/dev/null)
    echo "  $verb $resource: $RESULT"
  done
done
