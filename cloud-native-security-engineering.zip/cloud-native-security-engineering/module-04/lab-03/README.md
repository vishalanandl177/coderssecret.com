# Lab 3 — Identity in Distributed Systems
Demonstrate why Kubernetes service accounts are insufficient for cross-cluster identity and how SPIFFE bridges the gap.
```bash
./demo-sa-limitations.sh
```
