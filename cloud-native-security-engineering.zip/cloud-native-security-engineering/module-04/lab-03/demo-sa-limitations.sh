#!/bin/bash
echo "=== K8s Service Account token is cluster-scoped ==="
kubectl create token default
echo
echo "This token only works in THIS cluster."
echo "For cross-cluster identity, you need SPIFFE (Module 6)."
