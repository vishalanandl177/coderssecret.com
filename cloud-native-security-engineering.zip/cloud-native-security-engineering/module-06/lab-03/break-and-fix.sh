#!/bin/bash
echo "=== Step 1: Create entry with WRONG namespace selector ==="
kubectl exec -n spire spire-server-0 -- /opt/spire/bin/spire-server entry create \
  -spiffeID spiffe://example.org/broken \
  -parentID spiffe://example.org/ns/spire/sa/spire-agent \
  -selector k8s:ns:nonexistent-namespace \
  -selector k8s:sa:default

echo
echo "=== Step 2: Deploy pod in 'default' namespace ==="
kubectl run debug-pod --image=alpine -- sleep 3600

echo
echo "=== Step 3: Check agent logs for attestation failure ==="
kubectl logs -n spire daemonset/spire-agent --tail=10 | grep -i "no entry found\|attest"

echo
echo "=== Step 4: Fix — update the selector to match actual namespace ==="
echo "Delete the wrong entry and create with k8s:ns:default"
