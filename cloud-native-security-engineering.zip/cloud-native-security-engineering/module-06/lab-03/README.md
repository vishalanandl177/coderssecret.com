# Lab 3 — Debug SPIRE Attestation Failures
Intentionally misconfigure SPIRE and practice debugging.
```bash
./break-and-fix.sh
```
