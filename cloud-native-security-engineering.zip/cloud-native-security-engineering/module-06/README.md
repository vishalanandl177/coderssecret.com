# Module 06
> See [course page](https://coderssecret.com/courses/cloud-native-security-engineering) for full content.
