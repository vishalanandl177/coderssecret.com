# Lab 1 — Deploy SPIRE on Kubernetes
See the [Mastering SPIFFE & SPIRE course](https://coderssecret.com/courses/mastering-spiffe-spire/running-spire-on-kubernetes) for detailed SPIRE deployment labs.
```bash
./deploy-spire.sh
./verify.sh
```
