#!/bin/bash
set -e
kind create cluster --name spire-cns
kubectl create namespace spire
echo "Deploy SPIRE Server + Agent + Controller Manager"
echo "See module-05 of mastering-spiffe-spire repo for full manifests"
echo "Or use: kubectl apply -f https://raw.githubusercontent.com/vishalanandl177/mastering-spiffe-spire/main/module-05/lab-01/spire-server.yaml"
