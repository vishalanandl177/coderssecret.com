# Module 16 — Production Architecture & Capstone
Deploy the complete five-pillar cloud-native security platform.
```bash
cd capstone
./01-create-cluster.sh
./02-deploy-spire.sh
./03-deploy-apps-with-envoy.sh
./04-deploy-opa-kyverno.sh
./05-deploy-falco-tetragon.sh
./06-setup-vault.sh
./07-sign-images.sh
./08-deploy-monitoring.sh
./09-attack-simulation.sh
```
