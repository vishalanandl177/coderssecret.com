#!/bin/bash
set -e
cat > /tmp/capstone-kind.yaml << KIND
kind: Cluster
apiVersion: kind.x-k8s.io/v1alpha4
nodes:
  - role: control-plane
  - role: worker
  - role: worker
  - role: worker
KIND
kind create cluster --name capstone --config /tmp/capstone-kind.yaml
kubectl cluster-info
echo "✓ Capstone cluster created (1 control-plane + 3 workers)"
