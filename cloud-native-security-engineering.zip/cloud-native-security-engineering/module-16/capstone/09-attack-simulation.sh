#!/bin/bash
set -e
echo "=== Attack 1: Deploy rogue pod (no SVID) ==="
kubectl run rogue --image=alpine -- sleep 3600
kubectl exec rogue -- wget -q -O- http://api.default.svc:8080 2>&1 || echo "✓ BLOCKED: No valid SVID"

echo
echo "=== Attack 2: Unauthorized API access ==="
kubectl exec deploy/frontend -- curl -s -o /dev/null -w "%{http_code}" http://database:5432 || echo "✓ BLOCKED: OPA denies frontend->database"

echo
echo "=== Attack 3: Shell in container (Falco) ==="
kubectl exec deploy/api -- sh -c "echo 'should trigger Falco alert'"
echo "Check: kubectl logs -n falco -l app.kubernetes.io/name=falco --tail=5"

echo
echo "=== Attack 4: Deploy unsigned image ==="
kubectl run unsigned --image=alpine:latest 2>&1 || echo "✓ BLOCKED: Gatekeeper rejects unsigned images"

echo
echo "=== All five pillars tested ==="
