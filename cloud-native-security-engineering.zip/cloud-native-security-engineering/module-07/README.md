# Module 7 — Service Mesh Security
## Labs
- [lab-01: Deploy Istio with Strict mTLS](./lab-01)
- [lab-02: Identity-Based Authorization](./lab-02)
