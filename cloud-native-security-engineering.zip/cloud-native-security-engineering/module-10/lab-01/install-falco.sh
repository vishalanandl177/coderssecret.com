#!/bin/bash
set -e
helm repo add falcosecurity https://falcosecurity.github.io/charts
helm install falco falcosecurity/falco -n falco --create-namespace \
  --set falcosidekick.enabled=true \
  --set falcosidekick.webui.enabled=true
kubectl wait -n falco --for=condition=ready pod -l app.kubernetes.io/name=falco --timeout=120s
echo "✓ Falco installed"
