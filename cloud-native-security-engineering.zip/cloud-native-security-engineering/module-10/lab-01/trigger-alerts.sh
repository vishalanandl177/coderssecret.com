#!/bin/bash
echo "=== Triggering Falco alerts ==="
kubectl run trigger --image=alpine --rm -it --restart=Never -- sh -c "
echo 'Test 1: shell in container (Falco alert: Terminal shell in container)'
echo 'Test 2: reading sensitive file'
cat /etc/shadow 2>/dev/null || echo '/etc/shadow not readable (good)'
echo 'Test 3: unexpected outbound connection'
wget -q -O /dev/null http://example.com 2>/dev/null || true
"
echo
echo "=== Check Falco logs ==="
kubectl logs -n falco -l app.kubernetes.io/name=falco --tail=20
