# Module 10 — Runtime Security & Threat Detection
## Labs
- [lab-01: Detect Threats with Falco](./lab-01)
- [lab-02: Runtime Enforcement with Tetragon](./lab-02)
