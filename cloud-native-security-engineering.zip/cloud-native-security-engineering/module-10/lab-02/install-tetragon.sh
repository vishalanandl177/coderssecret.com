#!/bin/bash
set -e
helm repo add cilium https://helm.cilium.io
helm install tetragon cilium/tetragon -n kube-system
kubectl wait -n kube-system --for=condition=ready pod -l app.kubernetes.io/name=tetragon --timeout=120s
echo "✓ Tetragon installed"
