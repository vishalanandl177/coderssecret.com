# Lab 3 — Microsegmentation with Network Policies + mTLS
Layer network policies on top of mTLS for defense in depth.
