#!/bin/bash
set -e
mkdir -p certs && cd certs
openssl req -x509 -newkey ec -pkeyopt ec_paramgen_curve:prime256v1 -nodes -keyout ca.key -out ca.crt -days 365 -subj "/CN=Demo CA"
for svc in server client; do
  openssl req -newkey ec -pkeyopt ec_paramgen_curve:prime256v1 -nodes -keyout $svc.key -out $svc.csr -subj "/CN=$svc"
  openssl x509 -req -in $svc.csr -CA ca.crt -CAkey ca.key -CAcreateserial -out $svc.crt -days 1 -sha256
done
echo "✓ CA + server + client certs created in ./certs"
