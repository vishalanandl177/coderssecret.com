# Lab 1 — Implement mTLS Between Services
```bash
./create-certs.sh
./start-server.sh   # Terminal 1
./test-mtls.sh       # Terminal 2
```
