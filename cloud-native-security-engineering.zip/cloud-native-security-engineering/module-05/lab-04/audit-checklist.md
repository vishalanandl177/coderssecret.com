# East-West Security Audit Checklist

| Layer | Control | Verified |
|-------|---------|----------|
| Network | Default deny NetworkPolicy | [ ] |
| Network | Explicit allow rules per service pair | [ ] |
| Transport | mTLS enabled on all connections | [ ] |
| Transport | Certificate rotation < 1 hour | [ ] |
| Identity | SPIFFE SVIDs issued to all services | [ ] |
| Identity | SVIDs verified on every request | [ ] |
| Authorization | OPA policies for each service pair | [ ] |
| Authorization | Deny-by-default policy | [ ] |
