# Lab 4 — East-West Security Audit
Document the security improvement at each layer: flat network → network policies → mTLS → identity-based auth.
