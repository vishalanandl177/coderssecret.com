# Lab — Secure CI/CD Capstone
Build a complete secure pipeline: secret scan → build → sign → SBOM → deploy with OIDC.
```bash
# Review the secure workflow
cat secure-pipeline.yml
# Apply to your repo's .github/workflows/
```
