# Module 12 — Secure CI/CD Pipelines
## Labs
- [lab-01: Harden GitHub Actions](./lab-01)
- [lab-02: Secure Deployment Pipeline](./lab-02)
