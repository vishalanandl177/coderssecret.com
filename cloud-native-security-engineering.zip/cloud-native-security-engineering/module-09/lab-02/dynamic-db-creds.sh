#!/bin/bash
set -e
kubectl exec -n vault vault-0 -- vault secrets enable database
kubectl exec -n vault vault-0 -- vault write database/config/postgres \
  plugin_name=postgresql-database-plugin \
  allowed_roles="readonly" \
  connection_url="postgresql://{{username}}:{{password}}@postgres:5432/app?sslmode=disable" \
  username="vault_admin" \
  password="vault_password"
kubectl exec -n vault vault-0 -- vault write database/roles/readonly \
  db_name=postgres \
  creation_statements="CREATE ROLE \"{{name}}\" WITH LOGIN PASSWORD '{{password}}' VALID UNTIL '{{expiration}}'; GRANT SELECT ON ALL TABLES IN SCHEMA public TO \"{{name}}\";" \
  default_ttl="1h" \
  max_ttl="24h"
echo "✓ Dynamic DB credentials configured (1h TTL)"
echo "Test: vault read database/creds/readonly"
