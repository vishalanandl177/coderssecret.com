#!/bin/bash
set -e
helm repo add hashicorp https://helm.releases.hashicorp.com
helm install vault hashicorp/vault --set "server.dev.enabled=true" -n vault --create-namespace
kubectl wait -n vault --for=condition=ready pod/vault-0 --timeout=120s
kubectl exec -n vault vault-0 -- vault auth enable kubernetes
echo "✓ Vault deployed in dev mode with K8s auth"
