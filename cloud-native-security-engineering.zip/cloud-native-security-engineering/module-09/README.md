# Module 9 — Secrets Management & Machine Identity
## Labs
- [lab-01: Integrate Vault with Kubernetes](./lab-01)
- [lab-02: Dynamic Secret Rotation](./lab-02)
