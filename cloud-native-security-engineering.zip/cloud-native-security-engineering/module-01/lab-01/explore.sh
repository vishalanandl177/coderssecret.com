#!/bin/bash
set -e
echo "=== Default Service Accounts ==="
kubectl get sa --all-namespaces | grep default
echo
echo "=== ClusterRoleBindings (potential privilege escalation) ==="
kubectl get clusterrolebindings -o custom-columns=NAME:.metadata.name,ROLE:.roleRef.name,SUBJECTS:.subjects[*].name | head -20
echo
echo "=== Pods running as root ==="
kubectl get pods --all-namespaces -o jsonpath='{range .items[*]}{.metadata.namespace}/{.metadata.name}: UID={.spec.containers[0].securityContext.runAsUser}{"\n"}{end}' 2>/dev/null || echo "Check individual pods"
echo
echo "=== Secrets in default namespace ==="
kubectl get secrets
