#!/bin/bash
kind delete cluster --name attack-surface-demo
