# Lab 1 — Exploring the Kubernetes Attack Surface
## Run
```bash
./setup.sh
./explore.sh
./teardown.sh
```
