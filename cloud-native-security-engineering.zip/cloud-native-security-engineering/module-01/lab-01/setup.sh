#!/bin/bash
set -e
kind create cluster --name attack-surface-demo
echo "✓ Cluster created"
