# Module 1 — Introduction to Cloud Native Security
> [Course page](https://coderssecret.com/courses/cloud-native-security-engineering/introduction-cloud-native-security)
## Labs
- [lab-01: Exploring the Kubernetes Attack Surface](./lab-01)
- [lab-02: Analyzing Insecure Deployment Examples](./lab-02)
