# Lab 2 — Analyzing Insecure Deployment Examples
Review the insecure manifests in this folder, identify the security issues, then compare with the hardened versions.
```bash
diff insecure-deployment.yaml hardened-deployment.yaml
```
