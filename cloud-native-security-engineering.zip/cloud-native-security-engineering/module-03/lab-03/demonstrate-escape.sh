#!/bin/bash
echo "=== Host processes visible from container (hostPID) ==="
kubectl exec escape-demo -- ps aux | head -20
echo
echo "=== Host filesystem accessible (via /proc/1/root) ==="
kubectl exec escape-demo -- ls /proc/1/root/etc/ | head -10
echo
echo "=== This container has ESCAPED isolation. Fix: remove hostPID + privileged ==="
