# Module 3 — Containers & Workload Security
## Labs
- [lab-01: Harden an Insecure Container](./lab-01)
- [lab-02: Configure Pod Security Standards](./lab-02)
- [lab-03: Container Escape Demo](./lab-03)
