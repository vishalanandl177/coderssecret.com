# Module 13 — Observability & Security Monitoring
## Labs
- [lab-01: Security Dashboards](./lab-01)
- [lab-02: Audit Log Analysis](./lab-02)
