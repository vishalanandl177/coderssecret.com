#!/bin/bash
set -e
IMAGE=${1:-"ghcr.io/myorg/myapp:v1.0.0"}
echo "Signing image: $IMAGE"
cosign sign "$IMAGE"
echo
echo "Verifying signature..."
cosign verify "$IMAGE"
echo "✓ Image signed and verified"
