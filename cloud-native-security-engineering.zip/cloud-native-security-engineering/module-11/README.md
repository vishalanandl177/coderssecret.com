# Module 11 — Supply Chain Security
## Labs
- [lab-01: Sign and Verify Container Images](./lab-01)
- [lab-02: Generate and Analyze SBOMs](./lab-02)
