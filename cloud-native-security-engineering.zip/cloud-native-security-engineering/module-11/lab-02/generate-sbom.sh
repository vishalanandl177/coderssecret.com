#!/bin/bash
set -e
IMAGE=${1:-"nginx:1.27"}
echo "Generating SBOM for $IMAGE..."
syft "$IMAGE" -o spdx-json > sbom.json
echo "✓ SBOM generated: sbom.json"
echo
echo "Scanning for vulnerabilities..."
grype sbom:sbom.json
