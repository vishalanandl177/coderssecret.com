# Cloud Native Security Engineering

> Companion repository for the free course at [coderssecret.com/courses/cloud-native-security-engineering](https://coderssecret.com/courses/cloud-native-security-engineering)

The most practical beginner-to-advanced cloud-native security course — covering the **five pillars**: workload identity, Zero Trust, policy-as-code, runtime security, and supply chain security.

## Course Modules

| # | Module | Labs | Focus |
|---|--------|------|-------|
| 1 | [Introduction to Cloud Native Security](./module-01) | 2 | Threat landscape, security principles |
| 2 | [Kubernetes Foundations for Security](./module-02) | 3 | API flow, RBAC, attack surface |
| 3 | [Containers & Workload Security](./module-03) | 3 | Namespaces, seccomp, distroless |
| 4 | [Kubernetes Authentication & Authorization](./module-04) | 2 | OIDC, RBAC, service accounts |
| 5 | [Zero Trust Security Fundamentals](./module-05) | 2 | mTLS, microsegmentation |
| 6 | [SPIFFE & SPIRE Deep Dive](./module-06) | 2 | Workload identity, federation |
| 7 | [Service Mesh Security](./module-07) | 2 | Istio, Envoy, mTLS |
| 8 | [Policy-as-Code Security](./module-08) | 2 | OPA, Kyverno, admission |
| 9 | [Secrets Management & Machine Identity](./module-09) | 2 | Vault, dynamic secrets |
| 10 | [Runtime Security & Threat Detection](./module-10) | 2 | Falco, Tetragon, eBPF |
| 11 | [Supply Chain Security](./module-11) | 2 | Sigstore, SLSA, SBOM |
| 12 | [Secure CI/CD Pipelines](./module-12) | 2 | GitHub Actions, OIDC |
| 13 | [Observability & Security Monitoring](./module-13) | 2 | OpenTelemetry, audit logs |
| 14 | [Multi-Cluster & Multi-Cloud Security](./module-14) | 1 | Federation, trust boundaries |
| 15 | [AI Infrastructure Security](./module-15) | 2 | Agent identity, MCP, vector DB |
| 16 | [Production Architecture & Capstone](./module-16) | 1 | Full five-pillar platform |

## Prerequisites

- Linux/macOS with bash
- Docker installed
- kubectl installed
- [kind](https://kind.sigs.k8s.io/) for local Kubernetes
- [Helm](https://helm.sh/) for some labs
- OpenSSL for PKI labs

## Quick Start

```bash
git clone https://github.com/vishalanandl177/cloud-native-security-engineering.git
cd cloud-native-security-engineering/module-01/lab-01
./setup.sh
```

## Learning Paths

- **Beginner:** Modules 1-5 (foundations)
- **Intermediate:** Modules 6-10 (identity, mesh, policy, runtime)
- **Advanced:** Modules 11-16 (supply chain, CI/CD, multi-cloud, AI, capstone)

## About the Author

Created by **Vishal Anand** — Senior Product Engineer, creator of [DRF API Logger](https://github.com/vishalanandl177/DRF-API-Logger) (1.6M+ downloads), educator at [coderssecret.com](https://coderssecret.com).

## License

MIT
