#!/bin/bash
set -e
kind create cluster --name rbac-demo
kubectl cluster-info
echo "=== API Server flags ==="
docker exec rbac-demo-control-plane cat /etc/kubernetes/manifests/kube-apiserver.yaml | grep -E "enable-admission|authorization-mode|anonymous"
