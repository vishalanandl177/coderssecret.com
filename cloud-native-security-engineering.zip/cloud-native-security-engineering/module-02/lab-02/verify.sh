#!/bin/bash
kubectl apply -f rbac-least-privilege.yaml
echo "=== Can monitoring-agent list pods? ==="
kubectl auth can-i list pods --as=system:serviceaccount:default:monitoring-agent
echo "=== Can monitoring-agent delete pods? ==="
kubectl auth can-i delete pods --as=system:serviceaccount:default:monitoring-agent
echo "=== Can monitoring-agent list secrets? ==="
kubectl auth can-i list secrets --as=system:serviceaccount:default:monitoring-agent
