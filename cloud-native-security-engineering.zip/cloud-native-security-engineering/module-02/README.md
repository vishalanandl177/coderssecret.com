# Module 2 — Kubernetes Foundations for Security
> [Course page](https://coderssecret.com/courses/cloud-native-security-engineering/kubernetes-foundations-security)
## Labs
- [lab-01: Explore Kubernetes Security Components](./lab-01)
- [lab-02: Create Least-Privilege RBAC](./lab-02)
- [lab-03: Exploit Insecure RBAC](./lab-03)
