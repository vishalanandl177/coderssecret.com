# Lab 3 — Exploit Insecure RBAC
Demonstrates how overly broad RBAC leads to privilege escalation.
```bash
kubectl apply -f insecure-rbac.yaml
./exploit.sh
```
