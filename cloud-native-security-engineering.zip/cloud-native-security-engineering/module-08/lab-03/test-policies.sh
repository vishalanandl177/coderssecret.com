#!/bin/bash
set -e
echo "=== Testing OPA policies ==="
opa test ../lab-01/ -v 2>/dev/null || echo "Install OPA to test Rego policies"
echo
echo "=== Dry-run Kyverno policies ==="
kyverno apply ../lab-02/kyverno-require-limits.yaml --resource test-pod.yaml 2>/dev/null || echo "Install Kyverno CLI for dry-run"
