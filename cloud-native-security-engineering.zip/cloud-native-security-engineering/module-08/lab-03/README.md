# Lab 3 — Policy Testing in CI/CD
Test OPA and Kyverno policies before deploying them.
```bash
./test-policies.sh
```
