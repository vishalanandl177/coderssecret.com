# Module 8 — Policy-as-Code Security
## Labs
- [lab-01: Block Insecure Deployments with Gatekeeper](./lab-01)
- [lab-02: Enforce Security with Kyverno](./lab-02)
