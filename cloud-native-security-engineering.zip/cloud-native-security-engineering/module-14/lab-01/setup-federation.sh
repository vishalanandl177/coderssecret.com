#!/bin/bash
set -e
kind create cluster --name cluster-a
kind create cluster --name cluster-b
echo "Deploy SPIRE on each cluster with different trust domains"
echo "Exchange trust bundles for federation"
echo "See module-09 of mastering-spiffe-spire repo for detailed federation steps"
