# Lab 3.3 — Idempotent Consumer with Dedup

> Design a consumer that processes at-least-once messages exactly once via idempotency keys.

📚 **Course module:** [event-driven-asynchronous-systems](https://coderssecret.com/courses/distributed-systems-engineering/event-driven-asynchronous-systems)

**Difficulty:** Intermediate · **Time:** ~60 minutes

## Objective

Design a consumer that processes at-least-once messages exactly once via idempotency keys.

## Prerequisites

See the [parent module README](../README.md#prerequisites) for the full list.

## Steps

1. `docker compose up` starts Postgres + Kafka + the demo consumer.
2. Inspect the schema: `processed_messages` table with UNIQUE constraint on `idempotency_key`.
3. Send a unique message, then deliberately resend it (`python resend.py msg-id-123`).
4. Verify only ONE row was inserted in the application table; the duplicate insert was caught by the UNIQUE.
5. Verify metrics show duplicate count incrementing.

## Expected output

First message processes to completion. Duplicates are detected via the UNIQUE constraint and silently skipped. Metrics: `messages_processed{status="new"} = N`, `messages_processed{status="duplicate"} > 0`.

## Related

[Event-Driven & Asynchronous Systems module](https://coderssecret.com/courses/distributed-systems-engineering/event-driven-asynchronous-systems)
