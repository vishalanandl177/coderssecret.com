# Module 3 — Event-Driven & Asynchronous Systems

> Kafka, RabbitMQ, NATS, pub/sub, ordering, idempotency, backpressure.

📚 **Course module:** [coderssecret.com/courses/distributed-systems-engineering/event-driven-asynchronous-systems](https://coderssecret.com/courses/distributed-systems-engineering/event-driven-asynchronous-systems)

## Labs

| # | Lab | Difficulty | Time |
|---|---|---|---|
| 3.1 | [Kafka Event Pipeline End-to-End](lab-kafka-pipeline/) | Intermediate | 90 min |
| 3.2 | [Backpressure in a Reactive Pipeline](lab-backpressure/) | Intermediate | 60 min |
| 3.3 | [Idempotent Consumer with Dedup](lab-idempotent-consumer/) | Intermediate | 60 min |

## Prerequisites

- Docker + docker-compose
- Python 3.10+ or Go 1.21+
- `kcat` (formerly `kafkacat`) for Kafka verification
