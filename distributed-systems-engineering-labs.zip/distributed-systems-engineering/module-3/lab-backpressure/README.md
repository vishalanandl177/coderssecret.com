# Lab 3.2 — Backpressure in a Reactive Pipeline

> Reproduce a runaway producer; introduce bounded queues; observe stable throughput.

📚 **Course module:** [event-driven-asynchronous-systems](https://coderssecret.com/courses/distributed-systems-engineering/event-driven-asynchronous-systems)

**Difficulty:** Intermediate · **Time:** ~60 minutes

## Objective

Reproduce a runaway producer; introduce bounded queues; observe stable throughput.

## Prerequisites

See the [parent module README](../README.md#prerequisites) for the full list.

## Steps

1. Run `python unbounded.py` — an unbounded in-memory queue between producer and consumer.
2. Run with producer at 10x consumer rate (`PRODUCER_RPS=1000 CONSUMER_RPS=100 python unbounded.py`).
3. Watch memory grow via `docker stats` until OOM.
4. Switch to `python bounded.py` — same scenario, but bounded queue.
5. Observe blocking on the producer; system stabilises at consumer rate.

## Expected output

Unbounded: memory grows linearly until OOM (~30s on a 2GB container).
Bounded: producer blocks; system runs steady at the consumer's rate.

## Related

[Event-Driven & Asynchronous Systems module](https://coderssecret.com/courses/distributed-systems-engineering/event-driven-asynchronous-systems)
