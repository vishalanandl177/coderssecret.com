# Lab 3.1 — Kafka Event Pipeline End-to-End

> Build a producer/consumer pipeline with proper key-based partitioning and consumer groups.

📚 **Course module:** [event-driven-asynchronous-systems](https://coderssecret.com/courses/distributed-systems-engineering/event-driven-asynchronous-systems)

**Difficulty:** Intermediate · **Time:** ~90 minutes

## Objective

Build a producer/consumer pipeline with proper key-based partitioning and consumer groups.

## Prerequisites

See the [parent module README](../README.md#prerequisites) for the full list.

## Steps

1. `docker compose up` starts Kafka via the Bitnami image.
2. Run `python producer.py` to emit orders keyed by user_id.
3. Run `python consumer-billing.py` and `python consumer-audit.py` (separate consumer groups).
4. Verify per-key ordering on each partition with `kcat -t orders -p 0`.
5. Kill a broker (`docker compose stop kafka-2`); verify producer + consumers continue (replicated topic).

## Expected output

Both consumer groups receive every message independently. Per-user-id ordering preserved within each partition. Broker kill causes brief pause, then recovery.

## Related

[Event-Driven & Asynchronous Systems module](https://coderssecret.com/courses/distributed-systems-engineering/event-driven-asynchronous-systems)
