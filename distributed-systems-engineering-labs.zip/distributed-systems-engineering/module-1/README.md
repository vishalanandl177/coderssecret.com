# Module 1 — Foundations of Distributed Systems

> Build the mental model that every later module depends on.

📚 **Course module:** [coderssecret.com/courses/distributed-systems-engineering/foundations-distributed-systems](https://coderssecret.com/courses/distributed-systems-engineering/foundations-distributed-systems)

## What you'll learn

- Define a distributed system from a production-engineering perspective
- Internalise CAP and PACELC as decision frameworks, not academic theorems
- Reason about latency, availability, fault tolerance, and consistency as a coupled system
- Run the availability math on a real critical path

## Labs

| # | Lab | Difficulty | Time |
|---|---|---|---|
| 1.1 | [Latency Simulation Across Service Boundaries](lab-latency-simulation/) | Beginner | 45 min |
| 1.2 | [Failure Isolation Test](lab-failure-isolation/) | Beginner | 45 min |
| 1.3 | [Availability Math](lab-availability-math/) | Beginner | 30 min |

## Prerequisites

- Docker + docker-compose
- Python 3.10+ or Go 1.21+
- Basic shell familiarity
