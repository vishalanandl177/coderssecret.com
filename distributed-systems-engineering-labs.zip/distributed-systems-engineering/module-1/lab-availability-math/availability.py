"""Compute end-to-end availability for a chain of services.

Reads service definitions from architecture.md (markdown table parsed loosely)
or uses the built-in example.
"""
from typing import NamedTuple


class Service(NamedTuple):
    name: str
    availability: float  # e.g. 0.9995 for 99.95%


# Example architecture: e-commerce checkout critical path
EXAMPLE = [
    Service("api-gateway", 0.9999),
    Service("auth-svc", 0.9995),
    Service("cart-svc", 0.9990),
    Service("inventory-svc", 0.9950),
    Service("payment-svc", 0.9999),
    Service("order-svc", 0.9995),
]


def downtime_per_year(availability: float) -> str:
    minutes_per_year = 365 * 24 * 60
    down_minutes = (1 - availability) * minutes_per_year
    if down_minutes < 60:
        return f"{down_minutes:.1f}m"
    hours = down_minutes / 60
    if hours < 24:
        return f"{hours:.1f}h"
    days = hours / 24
    return f"{days:.1f}d"


def report(services: list[Service]) -> None:
    print("=== Critical-path availability calculation ===")
    print(f"{'Service':<20} {'Availability':>13} {'Outage/yr':>12}")
    print("─" * 50)

    weakest = min(services, key=lambda s: s.availability)
    end_to_end = 1.0
    for s in services:
        marker = "  ← WEAKEST" if s == weakest else ""
        print(f"{s.name:<20} {s.availability * 100:>12.2f}% {downtime_per_year(s.availability):>12}{marker}")
        end_to_end *= s.availability

    print("─" * 50)
    print(f"{'End-to-end:':<20} {end_to_end * 100:>12.2f}% {downtime_per_year(end_to_end):>12}")
    print()

    # Recommendation: hypothetical improvement on the weakest
    target = max(0.999, weakest.availability)
    if weakest.availability < 0.999:
        improved_total = end_to_end / weakest.availability * 0.999
        saved = downtime_per_year(end_to_end) + " → " + downtime_per_year(improved_total)
        print(f"Recommendation: improving {weakest.name} from {weakest.availability*100:.2f}% → 99.90%")
        print(f"                lifts end-to-end from {end_to_end*100:.2f}% → {improved_total*100:.2f}%")
        print(f"                (saves ~{saved})")


if __name__ == "__main__":
    report(EXAMPLE)
