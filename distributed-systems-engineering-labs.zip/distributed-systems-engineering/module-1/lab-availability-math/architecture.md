# Example Architecture: E-Commerce Checkout

A simplified real-world checkout path. Adjust the availabilities below
to model your own architecture.

| Service        | Availability | Notes                        |
|----------------|-------------:|------------------------------|
| api-gateway    | 99.99%       | AWS ALB                      |
| auth-svc       | 99.95%       | Internal microservice        |
| cart-svc       | 99.90%       | Newer service, less mature   |
| inventory-svc  | 99.50%       | Vendor-managed, weakest link |
| payment-svc    | 99.99%       | Stripe                       |
| order-svc      | 99.95%       | Internal microservice        |

The critical path runs all 6 in series, so end-to-end availability is the product.
