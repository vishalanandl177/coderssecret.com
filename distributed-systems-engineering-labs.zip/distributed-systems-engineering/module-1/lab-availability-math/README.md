# Lab 1.3 — Availability Math

> Calculate end-to-end availability for a real architecture and identify the weakest link.

📚 **Course module:** [Foundations of Distributed Systems](https://coderssecret.com/courses/distributed-systems-engineering/foundations-distributed-systems)

**Difficulty:** Beginner · **Time:** ~30 minutes

## Objective

Document a real microservice architecture (your own, or the fictional one in `architecture.md`), assign each service its measured or claimed availability, compute end-to-end availability for the critical path, and identify the single change that would most improve overall SLO.

This is a paper-and-spreadsheet exercise. The point is the discipline, not the tool.

## Prerequisites

- A spreadsheet (or `python` with pandas)

## Steps

### 1. Read the example architecture

```bash
cat architecture.md
```

The example shows a 6-service e-commerce checkout path with claimed per-service availabilities ranging from 99.5% to 99.99%.

### 2. Run the calculator

```bash
python availability.py
```

The output shows the multiplied availability across the critical path, per-service contribution, and the weakest link.

### 3. Modify the inputs

Open `architecture.md` and try:
- What does upgrading the weakest service from 99.5% to 99.9% buy you?
- What happens if one service drops from 99.99% to 99%?
- If your SLO is 99.95%, which architecture meets it?

### 4. Document a real one

Replicate the spreadsheet for a real microservice graph you operate (or one from a public post-mortem write-up). The find-and-fix recommendation is the deliverable.

## Expected output

```
=== Critical-path availability calculation ===
Service                Availability    Outage/yr
─────────────────────────────────────────────────
api-gateway              99.99%        52.6m
auth-svc                 99.95%        4h 22m
cart-svc                 99.90%        8h 45m
inventory-svc            99.50%        43h 49m  ← WEAKEST
payment-svc              99.99%        52.6m
order-svc                99.95%        4h 22m
─────────────────────────────────────────────────
End-to-end:              99.28%        63h 5m

Recommendation: improving inventory-svc from 99.50% → 99.90%
                lifts end-to-end from 99.28% → 99.69%
                (saves ~36 hours of yearly downtime)
```

## Discussion

- Why does adding more services almost always reduce availability?
- When does a 99.9% service legitimately depend on a 99% service? (Hint: optional / enriching dependencies)
- How do you make a service's *effective* availability higher than its raw availability? (Hint: caching, circuit breakers, fallbacks)

## Related course content

- [Foundations of Distributed Systems — Availability section](https://coderssecret.com/courses/distributed-systems-engineering/foundations-distributed-systems)
