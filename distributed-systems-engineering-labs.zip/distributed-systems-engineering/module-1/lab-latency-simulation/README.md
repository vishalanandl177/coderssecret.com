# Lab 1.1 — Latency Simulation Across Service Boundaries

> Measure how cross-service network hops accumulate latency in a real microservice topology.

📚 **Course module:** [Foundations of Distributed Systems](https://coderssecret.com/courses/distributed-systems-engineering/foundations-distributed-systems)

**Difficulty:** Beginner · **Time:** ~45 minutes

---

## Objective

You will spin up 5 small services (`A → B → C → D → E`) on docker-compose, send 1000 requests through the chain, and measure the cumulative latency. Compare to a single-monolith implementation that does the same logical work in-process.

The takeaway is concrete: each microservice boundary you cross is at least one network round-trip; the chain topology *imposes* a latency floor that no amount of CPU optimisation can remove.

## Prerequisites

- Docker ≥ 20.10
- docker-compose (or `docker compose` plugin)
- `curl` for sending requests
- Optional: `hey` or `vegeta` for higher-volume load

## Architecture

```
client ──→ A ──→ B ──→ C ──→ D ──→ E
                                   │
                                   ↓
                            response: { hop_count, total_ms }
```

Each service:
- Receives a JSON request with `{ count: N }`
- Adds 5ms of artificial work
- If not the last in the chain, forwards to the next service
- Returns the cumulative `count + 1` and the elapsed time

The **monolith** version does the same logical work in-process (no network).

## Run

```bash
# Start the chain
docker compose up --build

# Wait for healthchecks (~10s), then send a request
curl -s http://localhost:8080/process | jq

# Send 1000 requests and measure latency distribution
./bench.sh 1000

# Compare with the monolith
docker compose -f docker-compose.monolith.yml up --build -d
./bench.sh 1000 http://localhost:9090/process

# Tear down
docker compose down
docker compose -f docker-compose.monolith.yml down
```

## Expected output

```
=== Distributed (5-hop chain) ===
Requests: 1000
p50:  28ms
p95:  42ms
p99:  61ms

=== Monolith ===
Requests: 1000
p50:  6ms
p95:  9ms
p99:  14ms

Network tax: ~22ms p50 / ~47ms p99
```

The exact numbers vary by laptop, but the *ratio* (~5x latency penalty) is the lesson — the chain topology is the latency floor.

## Verification checklist

- [ ] `docker compose ps` shows 5 services running and healthy
- [ ] `curl localhost:8080/process` returns JSON with `hop_count: 5`
- [ ] Latency p99 of the distributed version is meaningfully higher than the monolith

## Discussion

- What happens to the chain latency if one service slows by 100ms?
- How does p99 vs p50 compare? Why?
- If you ran this across regions (50ms inter-region RTT), what would the chain p50 become?
- Where would caching help most?

## Files

```
.
├── README.md
├── docker-compose.yml          # 5-service chain
├── docker-compose.monolith.yml # equivalent single-process impl
├── services/
│   └── service.py              # parameterised service implementation
├── bench.sh                    # load-test script
└── monolith.py                 # in-process implementation
```

## Related course content

- [CAP Theorem section](https://coderssecret.com/courses/distributed-systems-engineering/foundations-distributed-systems) of Module 1
- [Latency propagation diagram](https://coderssecret.com/courses/distributed-systems-engineering/foundations-distributed-systems) in Module 1
- [Distributed Systems Algorithms blog](https://coderssecret.com/blog/distributed-systems-algorithms-production-guide)
