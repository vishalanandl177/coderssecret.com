#!/usr/bin/env bash
# Send N sequential requests and report p50/p95/p99 latency in ms.
# Usage: ./bench.sh [count] [url]
set -euo pipefail

COUNT="${1:-1000}"
URL="${2:-http://localhost:8080/process}"

echo "Sending $COUNT requests to $URL ..."

tmp=$(mktemp)
trap 'rm -f "$tmp"' EXIT

for _ in $(seq "$COUNT"); do
  # %{time_total} reports seconds
  curl -s -o /dev/null -w "%{time_total}\n" "$URL"
done > "$tmp"

# Convert seconds -> ms and sort
sorted=$(awk '{ printf "%.3f\n", $1 * 1000 }' "$tmp" | sort -n)

p() {
  pct=$1
  total=$(echo "$sorted" | wc -l)
  idx=$(( (pct * total + 99) / 100 ))
  echo "$sorted" | sed -n "${idx}p"
}

echo "Requests: $COUNT"
echo "p50:  $(p 50) ms"
echo "p95:  $(p 95) ms"
echo "p99:  $(p 99) ms"
