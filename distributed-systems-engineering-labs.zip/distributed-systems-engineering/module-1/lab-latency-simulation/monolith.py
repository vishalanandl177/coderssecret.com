"""Single-process equivalent of the 5-service chain.

Same logical work (5 hops, 5ms each), but executed sequentially
in-process — no network, no serialisation, no docker overhead.

Run:
  pip install fastapi uvicorn
  python monolith.py
  # then: curl http://localhost:9090/process
"""
import time

from fastapi import FastAPI

app = FastAPI()
WORK_MS = 5
HOPS = 5


@app.get("/process")
def process():
    started = time.perf_counter()
    for _ in range(HOPS):
        time.sleep(WORK_MS / 1000)
    return {"hop_count": HOPS, "total_ms": (time.perf_counter() - started) * 1000}


if __name__ == "__main__":
    import uvicorn

    uvicorn.run(app, host="0.0.0.0", port=9090)
