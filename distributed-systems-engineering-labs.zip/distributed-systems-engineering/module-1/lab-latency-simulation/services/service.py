"""Parameterised chain-service for the latency-simulation lab.

Each instance is one node in the A → B → C → D → E chain. Configure via
environment variables:

  SERVICE_NAME    A short label (e.g. "B")
  NEXT_SERVICE    URL of the next hop (empty = last in chain)
  WORK_MS         Artificial work per request (default: 5ms)
  PORT            HTTP port (default: 8000)

Run standalone:
  SERVICE_NAME=A NEXT_SERVICE=http://localhost:8001/process python service.py
"""
import os
import time
from urllib.request import Request, urlopen

from fastapi import FastAPI

NAME = os.getenv("SERVICE_NAME", "?")
NEXT = os.getenv("NEXT_SERVICE", "")
WORK_MS = int(os.getenv("WORK_MS", "5"))
PORT = int(os.getenv("PORT", "8000"))

app = FastAPI()


@app.get("/health")
def health():
    return {"name": NAME, "ok": True}


@app.get("/process")
def process():
    started = time.perf_counter()
    # Simulate work
    time.sleep(WORK_MS / 1000)

    if NEXT:
        # Forward to the next hop
        req = Request(NEXT)
        with urlopen(req, timeout=5) as resp:
            downstream = resp.read().decode("utf-8")
            import json
            ds = json.loads(downstream)
            hop_count = ds.get("hop_count", 0) + 1
            return {
                "name": NAME,
                "hop_count": hop_count,
                "total_ms": (time.perf_counter() - started) * 1000,
            }

    # Last in chain
    return {
        "name": NAME,
        "hop_count": 1,
        "total_ms": (time.perf_counter() - started) * 1000,
    }


if __name__ == "__main__":
    import uvicorn

    uvicorn.run(app, host="0.0.0.0", port=PORT)
