# Lab 1.2 — Failure Isolation Test

> Demonstrate failure isolation: kill one microservice and observe how the system degrades vs how a monolith fails.

📚 **Course module:** [Foundations of Distributed Systems](https://coderssecret.com/courses/distributed-systems-engineering/foundations-distributed-systems)

**Difficulty:** Beginner · **Time:** ~45 minutes

## Objective

Build a 3-service chain (`A → B → C`) where service A applies *graceful degradation* if C fails. Observe the failure mode under three configurations:

1. Naive chain — C fails, the request fails.
2. Chain with timeout — C hangs, A times out and returns 503.
3. Chain with timeout + fallback — C fails, A returns a degraded but valid response.

Compare to a monolith implementation where the equivalent function call simply propagates the exception.

## Prerequisites

- Docker + docker-compose
- `curl`, `jq`

## Setup

The lab reuses the chain-service implementation from [lab-latency-simulation/](../lab-latency-simulation/) but adds:

- **Timeout** support (`TIMEOUT_MS` environment variable on each service)
- **Fallback** support (`FALLBACK_BODY` environment variable returned when downstream fails)

## Steps

### 1. Run the naive chain (no timeout, no fallback)

```bash
docker compose -f docker-compose.naive.yml up -d --build
curl http://localhost:8080/process
# Now kill service C
docker compose -f docker-compose.naive.yml stop c
curl -v http://localhost:8080/process
# Observe: 5xx error, request hangs
```

### 2. Add timeouts

```bash
docker compose -f docker-compose.timeout.yml up -d --build
docker compose -f docker-compose.timeout.yml stop c
time curl -v http://localhost:8080/process
# Observe: 503 within ~500ms (the configured timeout)
```

### 3. Add graceful degradation

```bash
docker compose -f docker-compose.fallback.yml up -d --build
docker compose -f docker-compose.fallback.yml stop c
curl http://localhost:8080/process | jq
# Observe: 200 OK with a "degraded": true field in the response
```

### 4. Compare with the monolith

```bash
docker compose -f docker-compose.monolith.yml up -d --build
curl http://localhost:9090/process
# Edit monolith.py to throw an exception, restart, observe
# A monolith has no boundary for graceful degradation - the whole call fails
```

## Expected output

After the fallback configuration is active and C is stopped:

```json
{
  "name": "A",
  "downstream_status": "failed",
  "degraded": true,
  "fallback_used": "default cart",
  "elapsed_ms": 521
}
```

## Verification checklist

- [ ] Naive: kill C, see 5xx
- [ ] Timeout: kill C, see 503 within timeout window
- [ ] Fallback: kill C, see 200 with `degraded: true`
- [ ] Monolith: same kill-equivalent fails the whole request

## Discussion

- What's the trade-off between strict consistency (request fails if any dep fails) and graceful degradation (degraded response)?
- For a checkout flow with payment + recommendations + analytics dependencies, which is critical-path and which can degrade?
- How do you decide a fallback's content? Empty list? Cached old data? Default? When is each appropriate?

## Related course content

- [Reliability & Failure Engineering module (Module 7)](https://coderssecret.com/courses/distributed-systems-engineering/reliability-failure-engineering)
- [Distributed Systems Algorithms blog](https://coderssecret.com/blog/distributed-systems-algorithms-production-guide)
