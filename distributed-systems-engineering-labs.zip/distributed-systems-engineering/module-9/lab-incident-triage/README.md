# Lab 9.3 — Incident Triage from Telemetry

> Inject a partial failure; use only the dashboards and traces to identify root cause.

📚 **Course module:** [coderssecret.com/courses/distributed-systems-engineering/observability-debugging](https://coderssecret.com/courses/distributed-systems-engineering/observability-debugging)

**Difficulty:** Intermediate · **Time:** ~60 minutes

## Objective

Inject a partial failure; use only the dashboards and traces to identify root cause.

## Prerequisites

See the [parent module README](../README.md#prerequisites).

## Steps

1. `docker compose up` deploys 5 services + Jaeger + Grafana + Prometheus.
2. Run `./inject.sh` — adds 30% error rate at a random downstream service (don't peek at which).
3. Open Grafana; identify the affected service from the four golden signals.
4. Open Jaeger; pick a failed trace; identify the failing span.
5. Document the runbook (`runbook-template.md`).

## Expected output

From Grafana you'll see one service with elevated error rate. From Jaeger you'll find traces with failed spans on that service. The runbook documents the discovery flow.

## Related

[Incident Response Simulator](https://coderssecret.com/games/incident-response-simulator)
