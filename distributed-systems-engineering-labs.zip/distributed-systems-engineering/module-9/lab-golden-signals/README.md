# Lab 9.2 — Build the Four Golden Signals

> Add Prometheus instrumentation for latency, traffic, errors, saturation; build a Grafana dashboard.

📚 **Course module:** [coderssecret.com/courses/distributed-systems-engineering/observability-debugging](https://coderssecret.com/courses/distributed-systems-engineering/observability-debugging)

**Difficulty:** Intermediate · **Time:** ~90 minutes

## Objective

Add Prometheus instrumentation for latency, traffic, errors, saturation; build a Grafana dashboard.

## Prerequisites

See the [parent module README](../README.md#prerequisites).

## Steps

1. `docker compose up` starts the demo app + Prometheus + Grafana.
2. Inspect `app.py` — instrumented requests with histogram + counter + connection pool gauge.
3. Open Grafana at http://localhost:3000 (admin/admin); import `dashboards/golden-signals.json`.
4. Generate load with `./load.sh`; watch the four signals update.
5. Define an SLO ('p99 < 300ms over 30 days'); add a burn-rate alert.

## Expected output

Dashboard shows latency p50/p95/p99, RPS, error rate, saturation. SLO burn-rate alert fires when error budget burns too fast.

## Related

[Observability & Debugging module](https://coderssecret.com/courses/distributed-systems-engineering/observability-debugging)
