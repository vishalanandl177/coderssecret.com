# Lab 9.1 — Trace a Request End-to-End

> Instrument a 3-service chain with OpenTelemetry; trace a request across all three; visualise in Jaeger.

📚 **Course module:** [coderssecret.com/courses/distributed-systems-engineering/observability-debugging](https://coderssecret.com/courses/distributed-systems-engineering/observability-debugging)

**Difficulty:** Intermediate · **Time:** ~60 minutes

## Objective

Instrument a 3-service chain with OpenTelemetry; trace a request across all three; visualise in Jaeger.

## Prerequisites

See the [parent module README](../README.md#prerequisites).

## Steps

1. `docker compose up` starts Jaeger + 3 services (Python with OTel SDK).
2. Send a request: `curl http://localhost:8080/process`.
3. Open Jaeger UI at http://localhost:16686 and find the trace.
4. Identify the slowest span; modify the slow service's artificial latency; verify the trace updates.
5. Inspect W3C Trace Context propagation in HTTP headers via `curl -v`.

## Expected output

Trace shows root span + 2 children. Total time = sum of children + parent overhead. Slowest span is identifiable at a glance.

## Related

[Observability & Debugging module](https://coderssecret.com/courses/distributed-systems-engineering/observability-debugging)
