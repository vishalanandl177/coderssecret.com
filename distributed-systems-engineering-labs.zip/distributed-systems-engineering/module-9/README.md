# Module 9 — Observability & Debugging

> OpenTelemetry, Prometheus, Grafana, Jaeger, distributed tracing, golden signals.

📚 **Course module:** [coderssecret.com/courses/distributed-systems-engineering/observability-debugging](https://coderssecret.com/courses/distributed-systems-engineering/observability-debugging)

## Labs

| # | Lab | Difficulty | Time |
|---|---|---|---|
| 9.1 | [Trace a Request End-to-End](lab-end-to-end-tracing/) | Intermediate | 60 min |
| 9.2 | [Build the Four Golden Signals](lab-golden-signals/) | Intermediate | 90 min |
| 9.3 | [Incident Triage from Telemetry](lab-incident-triage/) | Intermediate | 60 min |

## Prerequisites

- Docker + docker-compose
- Python 3.10+ or Go 1.21+ (OTel SDK)
