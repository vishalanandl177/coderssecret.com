# Module 2 — Networking & Distributed Communication

> How services actually talk: TCP, HTTP/2, gRPC, service discovery, load balancing, retries.

📚 **Course module:** [coderssecret.com/courses/distributed-systems-engineering/networking-distributed-communication](https://coderssecret.com/courses/distributed-systems-engineering/networking-distributed-communication)

## Labs

| # | Lab | Difficulty | Time |
|---|---|---|---|
| 2.1 | [gRPC vs REST Latency Bake-off](lab-grpc-vs-rest/) | Beginner | 60 min |
| 2.2 | [Retry Storm Reproduction and Defence](lab-retry-storm/) | Intermediate | 90 min |
| 2.3 | [DNS-Caused Outage Triage](lab-dns-outage/) | Intermediate | 45 min |

## Prerequisites

- Docker + docker-compose
- Go 1.21+ (or Python 3.10+)
- `grpcurl` and `curl` for verification
