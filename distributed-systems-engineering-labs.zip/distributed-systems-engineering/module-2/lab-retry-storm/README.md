# Lab 2.2 — Retry Storm Reproduction and Defence

> Cause and contain a retry storm in a controlled environment.

📚 **Course module:** [networking-distributed-communication](https://coderssecret.com/courses/distributed-systems-engineering/networking-distributed-communication)

**Difficulty:** Intermediate · **Time:** ~90 minutes

## Objective

Cause and contain a retry storm in a controlled environment.

## Prerequisites

See the [parent module README](../README.md#prerequisites) for the full list.

## Steps

1. Stand up a 3-service chain via `docker compose up`.
2. Inject a 50% error rate at the bottom service (`./fault.sh inject 50%`).
3. Configure callers with naive retries (no backoff, no budget) — see `config/naive.yaml`.
4. Observe the QPS amplification on the bottom service in Grafana / docker logs.
5. Apply `config/backoff.yaml` (exponential backoff with jitter) — observe partial improvement.
6. Apply `config/budget.yaml` (retry budget capping retries at 10% of RPS) — observe full recovery.

## Expected output

With naive retries you'll see ~3x amplification on the failing service and no recovery. With backoff alone, ~50% reduction. With budget, the failing service recovers within 30s of the brownout ending.

## Related

[Rate Limiting Algorithms blog](https://coderssecret.com/blog/rate-limiting-algorithms-production-guide), [Reliability module](https://coderssecret.com/courses/distributed-systems-engineering/reliability-failure-engineering)
