# Lab 2.1 — gRPC vs REST Latency Bake-off

> Measure real latency and throughput of gRPC vs HTTP/JSON for the same logical workload.

📚 **Course module:** [networking-distributed-communication](https://coderssecret.com/courses/distributed-systems-engineering/networking-distributed-communication)

**Difficulty:** Beginner · **Time:** ~60 minutes

## Objective

Measure real latency and throughput of gRPC vs HTTP/JSON for the same logical workload.

## Prerequisites

See the [parent module README](../README.md#prerequisites) for the full list.

## Steps

1. Implement the same service interface as gRPC and HTTP/JSON (skeletons in `grpc/` and `rest/`).
2. Run `docker compose up` to start both servers.
3. Run a 5-minute load test at 100 / 1000 / 5000 RPS using `hey` or `vegeta`.
4. Capture p50/p95/p99 latency, throughput, CPU usage.
5. Compare wire size for a representative request (use `tcpdump` or the gRPC client logs).

## Expected output

gRPC shows ~2-5x lower wire bytes and ~30-50% lower latency at high RPS. The exact ratio depends on payload shape; the lesson is the order of magnitude.

## Related

[Networking & Distributed Communication module](https://coderssecret.com/courses/distributed-systems-engineering/networking-distributed-communication)
