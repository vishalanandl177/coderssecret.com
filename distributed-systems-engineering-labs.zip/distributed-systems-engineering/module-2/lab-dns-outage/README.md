# Lab 2.3 — DNS-Caused Outage Triage

> Reproduce a stale-DNS outage and walk through the triage flow.

📚 **Course module:** [networking-distributed-communication](https://coderssecret.com/courses/distributed-systems-engineering/networking-distributed-communication)

**Difficulty:** Intermediate · **Time:** ~45 minutes

## Objective

Reproduce a stale-DNS outage and walk through the triage flow.

## Prerequisites

See the [parent module README](../README.md#prerequisites) for the full list.

## Steps

1. `docker compose up` deploys a service with DNS TTL 300s and a client that calls it.
2. Run the `./trigger-stale-dns.sh` script — moves the service to a new IP behind the same DNS name.
3. Observe client failures for the TTL window (~5 min).
4. Repeat with TTL 5s (`docker compose -f docker-compose.short-ttl.yml up`) — observe smooth handoff.
5. Document the runbook (see `runbook-template.md`).

## Expected output

Stale-DNS run: client errors persist until the resolver cache expires.
Short-TTL run: handoff completes within seconds of the IP change.

## Related

[DNS-as-distributed-systems-risk section](https://coderssecret.com/courses/distributed-systems-engineering/networking-distributed-communication) of Module 2
