# Lab 10.1 — Kind Cluster from Scratch

> Stand up a multi-node kind cluster, deploy a 3-tier app, expose via Ingress.

📚 **Course module:** [coderssecret.com/courses/distributed-systems-engineering/kubernetes-cloud-native-distributed-systems](https://coderssecret.com/courses/distributed-systems-engineering/kubernetes-cloud-native-distributed-systems)

**Difficulty:** Beginner · **Time:** ~90 minutes

## Objective

Stand up a multi-node kind cluster, deploy a 3-tier app, expose via Ingress.

## Prerequisites

See the [parent module README](../README.md#prerequisites).

## Steps

1. `kind create cluster --config kind-config.yaml` (3 worker nodes).
2. Install nginx-ingress: `kubectl apply -f manifests/nginx-ingress.yaml`.
3. Deploy frontend / API / DB via `kubectl apply -f manifests/app/`.
4. Verify external access: `curl http://localhost/api/health`.
5. Scale the API: `kubectl scale deploy/api --replicas=5`; verify load balancing.

## Expected output

All three tiers running, ingress routes traffic correctly, scaling works as expected.

## Related

[Kubernetes & Cloud Native Distributed Systems module](https://coderssecret.com/courses/distributed-systems-engineering/kubernetes-cloud-native-distributed-systems)
