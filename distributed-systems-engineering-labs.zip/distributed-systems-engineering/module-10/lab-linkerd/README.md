# Lab 10.2 — Linkerd Service Mesh

> Install Linkerd; observe automatic mTLS; verify mesh observability.

📚 **Course module:** [coderssecret.com/courses/distributed-systems-engineering/kubernetes-cloud-native-distributed-systems](https://coderssecret.com/courses/distributed-systems-engineering/kubernetes-cloud-native-distributed-systems)

**Difficulty:** Intermediate · **Time:** ~90 minutes

## Objective

Install Linkerd; observe automatic mTLS; verify mesh observability.

## Prerequisites

See the [parent module README](../README.md#prerequisites).

## Steps

1. `kind create cluster --name dse-mesh`.
2. Install Linkerd CLI and control plane: `linkerd install | kubectl apply -f -`.
3. Inject sidecars into the demo namespace: `kubectl annotate ns demo linkerd.io/inject=enabled`.
4. Verify mTLS via Linkerd Viz: `linkerd viz dashboard`.
5. Inject failure with Toxiproxy; observe retry behaviour.

## Expected output

All sidecar-to-sidecar traffic is mTLS. Viz dashboard shows live success rate, latency, and retry counts.

## Related

[Kubernetes & Cloud Native Distributed Systems module](https://coderssecret.com/courses/distributed-systems-engineering/kubernetes-cloud-native-distributed-systems)
