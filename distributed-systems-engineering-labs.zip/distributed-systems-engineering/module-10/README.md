# Module 10 — Kubernetes & Cloud Native Distributed Systems

> Kubernetes architecture, service mesh, ingress, StatefulSets, autoscaling.

📚 **Course module:** [coderssecret.com/courses/distributed-systems-engineering/kubernetes-cloud-native-distributed-systems](https://coderssecret.com/courses/distributed-systems-engineering/kubernetes-cloud-native-distributed-systems)

## Labs

| # | Lab | Difficulty | Time |
|---|---|---|---|
| 10.1 | [Kind Cluster from Scratch](lab-kind-cluster/) | Beginner | 90 min |
| 10.2 | [Linkerd Service Mesh](lab-linkerd/) | Intermediate | 90 min |
| 10.3 | [StatefulSet for a Database](lab-statefulset-postgres/) | Intermediate | 60 min |

## Prerequisites

- Docker
- kind
- kubectl
- linkerd CLI (for Lab 10.2)
