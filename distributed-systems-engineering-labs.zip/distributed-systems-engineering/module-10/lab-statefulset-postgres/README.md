# Lab 10.3 — StatefulSet for a Database

> Deploy Postgres as a StatefulSet with persistent storage; verify pod identity stability.

📚 **Course module:** [coderssecret.com/courses/distributed-systems-engineering/kubernetes-cloud-native-distributed-systems](https://coderssecret.com/courses/distributed-systems-engineering/kubernetes-cloud-native-distributed-systems)

**Difficulty:** Intermediate · **Time:** ~60 minutes

## Objective

Deploy Postgres as a StatefulSet with persistent storage; verify pod identity stability.

## Prerequisites

See the [parent module README](../README.md#prerequisites).

## Steps

1. `kind create cluster --name dse-stateful`.
2. Define a StatefulSet with PVC template (`manifests/statefulset.yaml`).
3. Deploy 3 replicas; verify pod names are postgres-0, postgres-1, postgres-2.
4. Kill postgres-1: `kubectl delete pod postgres-1`.
5. Verify the new pod has the same name and re-attaches the same PVC.
6. Demonstrate stable network identity: `nslookup postgres-1.postgres-headless`.

## Expected output

Pods have stable identities and stable storage. Pod kill -> reschedule with same PVC = no data loss.

## Related

[Kubernetes & Cloud Native Distributed Systems module](https://coderssecret.com/courses/distributed-systems-engineering/kubernetes-cloud-native-distributed-systems)
