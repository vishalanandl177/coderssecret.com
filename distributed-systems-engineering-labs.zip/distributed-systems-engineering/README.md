# Distributed Systems Engineering — Course Labs

[![Course](https://img.shields.io/badge/Course-CodersSecret-orange?style=flat-square)](https://coderssecret.com/courses/distributed-systems-engineering)
[![License](https://img.shields.io/badge/License-MIT-green?style=flat-square)](LICENSE)
[![Free](https://img.shields.io/badge/Free-Forever-22c55e?style=flat-square)](https://coderssecret.com)

Lab repository for the free **[Distributed Systems Engineering: Building Scalable, Reliable & Secure Systems](https://coderssecret.com/courses/distributed-systems-engineering)** course on CodersSecret.

A production-grade, beginner-friendly but deeply practical course on how real distributed systems actually work — from foundations through Kubernetes, observability, Zero Trust, and real-world failure recovery.

## Repository Structure

```
distributed-systems-engineering/
├── module-1/   Foundations of Distributed Systems
├── module-2/   Networking & Distributed Communication
├── module-3/   Event-Driven & Asynchronous Systems
├── module-4/   Distributed Data Management
├── module-5/   Consensus & Coordination
├── module-6/   Scalability Engineering
├── module-7/   Reliability & Failure Engineering
├── module-8/   Distributed Security & Zero Trust
├── module-9/   Observability & Debugging
├── module-10/  Kubernetes & Cloud Native Distributed Systems
├── module-11/  Real-World Failure Scenarios
└── module-12/  Production System Design & Capstone
```

Each module directory contains 2–3 hands-on labs. Each lab has its own README with objective, prerequisites, step-by-step instructions, expected output, and troubleshooting.

## Modules

| # | Module | Labs |
|---|---|---|
| 1 | [Foundations of Distributed Systems](module-1/) | 3 |
| 2 | [Networking & Distributed Communication](module-2/) | 3 |
| 3 | [Event-Driven & Asynchronous Systems](module-3/) | 3 |
| 4 | [Distributed Data Management](module-4/) | 3 |
| 5 | [Consensus & Coordination](module-5/) | 3 |
| 6 | [Scalability Engineering](module-6/) | 3 |
| 7 | [Reliability & Failure Engineering](module-7/) | 3 |
| 8 | [Distributed Security & Zero Trust](module-8/) | 3 |
| 9 | [Observability & Debugging](module-9/) | 3 |
| 10 | [Kubernetes & Cloud Native Distributed Systems](module-10/) | 3 |
| 11 | [Real-World Failure Scenarios](module-11/) | 3 |
| 12 | [Production System Design & Capstone](module-12/) | 3 |

**Total: 36 hands-on labs** across distributed systems foundations, networking, event-driven systems, data management, consensus, scalability, reliability, security, observability, Kubernetes, failure scenarios, and capstone production design.

## Prerequisites

Most labs run on a laptop with:

- **Docker** ≥ 20.10
- **docker-compose** ≥ 2.0 (or `docker compose` plugin)
- **kind** (Kubernetes in Docker) for the K8s-focused labs
- **kubectl** for Kubernetes labs
- **Go** ≥ 1.21 *or* **Python** ≥ 3.10 — most labs offer both implementations
- **make** for the lab task runners

Optional for advanced labs:

- **helm** ≥ 3.0
- **istioctl** / `linkerd` CLI for service-mesh labs
- A small cloud account (AWS/GCP free tier) for some Module 12 labs

## How to Use

1. **Pick a module** — start with Module 1 if you're new to distributed systems.
2. **Read the module README** for context on what you'll build.
3. **Open the first lab's README** for prerequisites and step-by-step instructions.
4. **Run the lab** — most ship with `docker-compose up` or `make run` to get going.
5. **Verify expected output** using the verification commands in the lab README.
6. **Move to the next lab** in the module, or skip ahead.

## Course Reference

Each lab links back to the corresponding course module on CodersSecret:

- 📚 [Course landing page](https://coderssecret.com/courses/distributed-systems-engineering)
- 🛡️ Related course: [Mastering SPIFFE & SPIRE](https://coderssecret.com/courses/mastering-spiffe-spire) (deep dive on workload identity)
- 🔐 Related course: [Cloud Native Security Engineering](https://coderssecret.com/courses/cloud-native-security-engineering) (Kubernetes-native security)
- 🤖 Related course: [Production RAG Systems Engineering](https://coderssecret.com/courses/production-rag-systems-engineering) (AI infrastructure)
- 🎮 [Security Simulators](https://coderssecret.com/games) — interactive scenario-based games for hands-on practice

## Contributing

Issues, pull requests, and suggestions welcome. See [CONTRIBUTING.md](CONTRIBUTING.md).

If a lab is unclear, broken, or could be improved — open an issue. The course and the labs co-evolve.

## License

[MIT](LICENSE) — code is yours to use commercially, modify, redistribute, no attribution required (though a courteous link back to the course is appreciated).

## About the Course

The course is taught by **Vishal Anand**, a Senior Product Engineer and Tech Lead with hands-on experience building production distributed systems at scale. Creator of [DRF API Logger](https://pypi.org/project/drf-api-logger/) (1.6M+ downloads) and the Mastering SPIFFE & SPIRE course.

Built from operational reality — no theory without code, no concepts without labs.
