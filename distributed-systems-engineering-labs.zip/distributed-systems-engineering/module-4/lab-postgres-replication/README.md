# Lab 4.1 — Postgres Streaming Replication + Failover

> Set up Postgres primary + replica, force failover, observe data loss window with sync vs async replication.

📚 **Course module:** [coderssecret.com/courses/distributed-systems-engineering/distributed-data-management](https://coderssecret.com/courses/distributed-systems-engineering/distributed-data-management)

**Difficulty:** Intermediate · **Time:** ~60 minutes

## Objective

Set up Postgres primary + replica, force failover, observe data loss window with sync vs async replication.

## Prerequisites

See the [parent module README](../README.md#prerequisites).

## Steps

1. `docker compose up` starts a Postgres primary + 1 replica with streaming replication.
2. Run async replication (default in compose); cause primary crash mid-write (`docker compose stop pg-primary`); measure data loss with the post-crash row count.
3. Switch to synchronous_commit=on (`scripts/enable-sync.sh`); rerun; verify zero data loss.
4. Compare write latency before and after.

## Expected output

Async: a few seconds of writes lost. Sync: zero loss, but ~10-30% higher write latency.

## Related

[Distributed Data Management module](https://coderssecret.com/courses/distributed-systems-engineering/distributed-data-management)
