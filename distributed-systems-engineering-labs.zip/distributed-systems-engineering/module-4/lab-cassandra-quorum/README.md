# Lab 4.2 — Cassandra Quorum Behaviour

> Run a 3-node Cassandra cluster, vary consistency levels, observe behaviour during node failure.

📚 **Course module:** [coderssecret.com/courses/distributed-systems-engineering/distributed-data-management](https://coderssecret.com/courses/distributed-systems-engineering/distributed-data-management)

**Difficulty:** Intermediate · **Time:** ~90 minutes

## Objective

Run a 3-node Cassandra cluster, vary consistency levels, observe behaviour during node failure.

## Prerequisites

See the [parent module README](../README.md#prerequisites).

## Steps

1. `docker compose up` starts a 3-node Cassandra cluster (RF=3).
2. Write with CL=QUORUM via `./write.sh`; verify reads see latest with CL=QUORUM.
3. Kill one node (`docker compose stop cassandra-2`); verify QUORUM still works (2 of 3 = quorum).
4. Kill two nodes; verify QUORUM fails; CL=ONE still works (eventual consistency only).
5. Restart nodes; verify hinted handoff replays the missed writes.

## Expected output

Demonstrates W+R>N math live: 1 failure tolerated at QUORUM, 2 failures tolerated at ONE (eventually consistent only).

## Related

[Distributed Systems Algorithms blog](https://coderssecret.com/blog/distributed-systems-algorithms-production-guide)
