# Module 4 — Distributed Data Management

> Replication, sharding, partitioning, consistency models, quorum systems.

📚 **Course module:** [coderssecret.com/courses/distributed-systems-engineering/distributed-data-management](https://coderssecret.com/courses/distributed-systems-engineering/distributed-data-management)

## Labs

| # | Lab | Difficulty | Time |
|---|---|---|---|
| 4.1 | [Postgres Streaming Replication + Failover](lab-postgres-replication/) | Intermediate | 60 min |
| 4.2 | [Cassandra Quorum Behaviour](lab-cassandra-quorum/) | Intermediate | 90 min |
| 4.3 | [Hot Partition Reproduction](lab-hot-partition/) | Intermediate | 45 min |

## Prerequisites

- Docker + docker-compose
- `psql` and `cqlsh` clients
- 8 GB+ RAM (Cassandra is hungry)
