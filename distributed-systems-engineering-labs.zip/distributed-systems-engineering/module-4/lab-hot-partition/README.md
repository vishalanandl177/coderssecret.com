# Lab 4.3 — Hot Partition Reproduction

> Cause and mitigate a hot partition in Redis Cluster.

📚 **Course module:** [coderssecret.com/courses/distributed-systems-engineering/distributed-data-management](https://coderssecret.com/courses/distributed-systems-engineering/distributed-data-management)

**Difficulty:** Intermediate · **Time:** ~45 minutes

## Objective

Cause and mitigate a hot partition in Redis Cluster.

## Prerequisites

See the [parent module README](../README.md#prerequisites).

## Steps

1. `docker compose up` starts Redis Cluster (3 primary, 3 replica).
2. Run `python load-skewed.py` — sends 90% of traffic to one key.
3. Observe per-node QPS via `redis-cli --stat`; identify the hot node.
4. Apply key salting via `python load-salted.py` (key:0..9 distribution).
5. Confirm load balances across nodes.

## Expected output

Skewed run: one node at ~90% CPU, others at ~5%. Salted run: even distribution across all nodes.

## Related

[Caching Strategies blog](https://coderssecret.com/blog/caching-strategies-production-guide)
