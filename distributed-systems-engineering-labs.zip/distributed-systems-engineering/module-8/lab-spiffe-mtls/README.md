# Lab 8.1 — mTLS Between Two Services with SPIFFE

> Deploy two services on Kubernetes; bootstrap mTLS using SPIRE-issued SVIDs.

📚 **Course module:** [coderssecret.com/courses/distributed-systems-engineering/distributed-security-zero-trust](https://coderssecret.com/courses/distributed-systems-engineering/distributed-security-zero-trust)

**Difficulty:** Intermediate · **Time:** ~120 minutes

## Objective

Deploy two services on Kubernetes; bootstrap mTLS using SPIRE-issued SVIDs.

## Prerequisites

See the [parent module README](../README.md#prerequisites).

## Steps

1. `kind create cluster --name dse-spiffe`.
2. Install SPIRE Server + Agent via `kubectl apply -f manifests/spire/`.
3. Register two workloads: `./register.sh` creates registration entries with namespace/SA selectors.
4. Implement an mTLS server using go-spiffe (`server/main.go`) and a client (`client/main.go`).
5. Run `make verify` — the client connects to the server, both verify each other's SPIFFE ID via mTLS.
6. Tamper test: try connecting from an unregistered workload — verify it's rejected.

## Expected output

Both services authenticate each other by SPIFFE ID. SVIDs are 1-hour validity, auto-rotated by the SPIRE Agent over the Workload API.

## Related

Take the dedicated [Mastering SPIFFE & SPIRE course](https://coderssecret.com/courses/mastering-spiffe-spire) for 13 modules of depth on this topic
