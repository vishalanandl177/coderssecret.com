# Lab 8.2 — OPA Authorization at Envoy

> Add OPA ext_authz to Envoy; enforce SPIFFE-ID-based access policy.

📚 **Course module:** [coderssecret.com/courses/distributed-systems-engineering/distributed-security-zero-trust](https://coderssecret.com/courses/distributed-systems-engineering/distributed-security-zero-trust)

**Difficulty:** Advanced · **Time:** ~90 minutes

## Objective

Add OPA ext_authz to Envoy; enforce SPIFFE-ID-based access policy.

## Prerequisites

See the [parent module README](../README.md#prerequisites).

## Steps

1. `docker compose up` starts Envoy + OPA sidecar + 2 demo services.
2. Inspect `policies/access.rego` — only `spiffe://example.com/ns/orders/sa/orders-svc` may call payments.
3. Send authorized call: `./call.sh orders payments` — 200 OK.
4. Send unauthorized call: `./call.sh marketing payments` — 403 Forbidden, OPA decision logged.
5. Modify the policy, reload OPA (`opa eval`), retest.

## Expected output

Authorized calls succeed (200). Unauthorized rejected at Envoy via OPA decision; the application service never sees the request.

## Related

[Mastering SPIFFE & SPIRE — Authorization Policy Enforcement](https://coderssecret.com/courses/mastering-spiffe-spire/authorization-policy-enforcement)
