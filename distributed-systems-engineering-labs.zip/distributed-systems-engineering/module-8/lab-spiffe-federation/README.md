# Lab 8.3 — SPIFFE Federation Across Two Clusters

> Stand up two kind clusters; federate trust; have a workload in cluster A authenticate to a workload in cluster B.

📚 **Course module:** [coderssecret.com/courses/distributed-systems-engineering/distributed-security-zero-trust](https://coderssecret.com/courses/distributed-systems-engineering/distributed-security-zero-trust)

**Difficulty:** Advanced · **Time:** ~120 minutes

## Objective

Stand up two kind clusters; federate trust; have a workload in cluster A authenticate to a workload in cluster B.

## Prerequisites

See the [parent module README](../README.md#prerequisites).

## Steps

1. `kind create cluster --name cluster-a` and `kind create cluster --name cluster-b`.
2. Install SPIRE in each with distinct trust domains: `example.com` and `other.example`.
3. Configure bundle endpoint exchange: `scripts/federate.sh`.
4. Deploy a workload in cluster-a that calls a workload in cluster-b via mTLS.
5. Verify the cross-cluster call succeeds; both sides validate the federated SPIFFE ID.

## Expected output

Cross-cluster mTLS works without VPN, shared secrets, or per-cluster credentials. Bundle endpoints automatically refresh trust bundles.

## Related

[Mastering SPIFFE & SPIRE — Advanced SPIRE Architectures](https://coderssecret.com/courses/mastering-spiffe-spire/advanced-spire-architectures)
