# Module 8 — Distributed Security & Zero Trust

> mTLS, SPIFFE/SPIRE, OPA, federation across trust domains.

📚 **Course module:** [coderssecret.com/courses/distributed-systems-engineering/distributed-security-zero-trust](https://coderssecret.com/courses/distributed-systems-engineering/distributed-security-zero-trust)

## Labs

| # | Lab | Difficulty | Time |
|---|---|---|---|
| 8.1 | [mTLS Between Two Services with SPIFFE](lab-spiffe-mtls/) | Intermediate | 120 min |
| 8.2 | [OPA Authorization at Envoy](lab-opa-envoy/) | Advanced | 90 min |
| 8.3 | [SPIFFE Federation Across Two Clusters](lab-spiffe-federation/) | Advanced | 120 min |

## Prerequisites

- kind + kubectl
- Go 1.21+ (go-spiffe SDK)
- For deeper SPIFFE/SPIRE labs, see the dedicated [Mastering SPIFFE & SPIRE course](https://coderssecret.com/courses/mastering-spiffe-spire)
