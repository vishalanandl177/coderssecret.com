# Contributing

Thanks for considering a contribution to the Distributed Systems Engineering course labs.

## Reporting Issues

If a lab is unclear, broken, or could be improved:

1. Open a [GitHub Issue](https://github.com/vishalanandl177/distributed-systems-engineering/issues) describing what you tried, what you expected, and what happened.
2. Include the module/lab number, your OS, and relevant tool versions (Docker, kubectl, kind).
3. If reproducible, paste the failing command and its output.

## Pull Requests

PRs welcome for:

- **Lab clarifications** — fixing typos, ambiguous instructions, missing prerequisites.
- **New verification commands** — better ways to check that a lab worked.
- **Additional implementations** — most labs ship in Go or Python; PRs adding the other are welcome.
- **OS-specific notes** — if a lab works differently on macOS vs Linux, document it.

Before opening a PR:

1. Test the lab end-to-end on a fresh checkout.
2. Update the README if you change behaviour.
3. Keep commits focused — one logical change per commit.

## Lab Structure Convention

Each lab follows this structure:

```
module-N/lab-name/
├── README.md           # Objective, prereqs, steps, expected output
├── docker-compose.yml  # If the lab uses Docker Compose
├── manifests/          # If the lab uses Kubernetes manifests
├── src/                # Source code (Go, Python, etc.)
├── Makefile            # Optional task runner: make run, make verify
└── ...
```

The README is the source of truth. If a step in the README does not work end-to-end, treat it as a bug and either fix the steps or fix the code.

## License

By contributing, you agree your contributions are licensed under the [MIT License](LICENSE), the same license as the rest of the repo.
