# Capstone — [System Name] Production Architecture

**Author:** your name
**Date:** YYYY-MM-DD

---

## Overview

One-page summary: what the system does, who uses it, headline scale numbers, and the 3 most important architectural choices you made.

## 1. Architecture diagram

A high-level diagram showing every service, datastore, and external dependency. Use mermaid, draw.io, or hand-drawn SVG — accuracy matters more than aesthetics.

## 2. Communication choices per boundary

For each cross-service boundary:

| From | To | Protocol | Why |
|---|---|---|---|
| api-gateway | auth-svc | gRPC + mTLS | Strongly-typed, low latency, fits internal service-to-service |
| auth-svc | users-db | TCP/SQL | Standard Postgres protocol |
| api-gateway | analytics-svc | Kafka (async) | Decouples analytics from request path |
| ... | ... | ... | ... |

## 3. Data model + partitioning strategy

For each datastore:

- **What's stored:** entity types, expected volume
- **Partitioning key:** and why (hash vs range, what access pattern dominates)
- **Replication:** RF, sync vs async, region scope
- **Consistency model:** linearizable / eventual / tunable

## 4. Replication & consistency guarantees

- What does the system promise to clients about read-after-write?
- What happens during a network partition? (CP vs AP choice per service)
- What's the maximum data-loss window (RPO)?

## 5. Autoscaling & capacity plan

- Per-service autoscaling: HPA on what metric, min/max replicas
- Node-level scaling: Karpenter / Cluster Autoscaler config
- Capacity reservation: % of baseline as reserved capacity
- Spot/preemptible usage where applicable

## 6. Reliability patterns

- Circuit breakers (per dependency, with state-transition rules)
- Retry policies (with budgets, backoff, jitter)
- Bulkheads (resource isolation)
- Graceful degradation paths (which deps are critical, which enrich)
- PodDisruptionBudgets

## 7. Security architecture

- Workload identity: SPIFFE/SPIRE? Service mesh-managed? Cloud-native (IRSA)?
- mTLS coverage: mesh-wide STRICT? Per-namespace?
- Authorization: OPA? In-app? Per-route?
- Secrets: Secrets Manager? Vault? CSI driver?
- API security: external auth model (OAuth, JWT)

## 8. Observability stack

- Tracing: OpenTelemetry → Jaeger/Tempo
- Metrics: Prometheus → Grafana
- Logs: Loki/Elasticsearch
- SLOs: per service, with error budgets

## 9. Deployment architecture

- CI/CD pipeline (GitHub Actions / Argo CD / Flux / Spinnaker)
- Regions & topology
- Rollout strategy (blue-green, canary, progressive)
- Rollback plan

## 10. DR & multi-region

- RPO and RTO targets
- Active-passive or active-active sharded
- DR drill cadence
- Backup retention policy

## Defended trade-offs

For each significant architectural choice, write 1-2 paragraphs framing it as "X chosen because the trade-off was Y vs Z; here is which I optimised for and why".

The goal: someone can read this document and ask any "why X?" question, and the answer is in here.

## Open questions / known gaps

What you couldn't resolve, and what would need to be addressed before going to production.
