# Lab 12.2 — DR Drill

> Practice a full disaster recovery drill from backup.

📚 **Course module:** [coderssecret.com/courses/distributed-systems-engineering/production-system-design-capstone](https://coderssecret.com/courses/distributed-systems-engineering/production-system-design-capstone)

**Difficulty:** Advanced · **Time:** ~120 minutes

## Objective

Practice a full disaster recovery drill from backup.

## Prerequisites

See the [parent module README](../README.md#prerequisites).

## Steps

1. `docker compose up` deploys a stateful service with backup automation.
2. Take a snapshot: `./backup.sh`.
3. "Destroy" the service: `docker compose down -v` (volumes too).
4. Restore from snapshot to a fresh service: `./restore.sh snapshot-1234.dump`.
5. Measure actual RTO; identify gaps in the runbook.
6. Document the gap-fill plan.

## Expected output

RTO measured against the SLO. Lab finds the inevitable gaps (missing secrets restoration, dependency-order startup, DNS propagation, etc.).

## Related

[Production System Design module](https://coderssecret.com/courses/distributed-systems-engineering/production-system-design-capstone)
