# Lab 12.1 — Multi-Region Active-Active Demo

> Stand up a small active-active app across two simulated regions; observe failover.

📚 **Course module:** [coderssecret.com/courses/distributed-systems-engineering/production-system-design-capstone](https://coderssecret.com/courses/distributed-systems-engineering/production-system-design-capstone)

**Difficulty:** Advanced · **Time:** ~120 minutes

## Objective

Stand up a small active-active app across two simulated regions; observe failover.

## Prerequisites

See the [parent module README](../README.md#prerequisites).

## Steps

1. `kind create cluster --name region-east` and `kind create cluster --name region-west`.
2. Deploy app + DB in each cluster (`manifests/region-a/` and `manifests/region-b/`).
3. Configure CRDT-style or LWW conflict resolution.
4. Simulate a network partition with Toxiproxy: `./partition.sh`.
5. Observe behaviour: both sides accept writes; reconciliation begins on heal.
6. Heal partition; verify convergence (or document the conflict that requires manual resolution).

## Expected output

Active-active works for read-heavy data; conflict resolution needed for writes-with-consequence. Lab makes the trade-off explicit.

## Related

[Production System Design module](https://coderssecret.com/courses/distributed-systems-engineering/production-system-design-capstone)
