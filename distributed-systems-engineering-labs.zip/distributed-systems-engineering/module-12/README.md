# Module 12 — Production System Design & Capstone

> Multi-region, disaster recovery, capstone production architecture exercise.

📚 **Course module:** [coderssecret.com/courses/distributed-systems-engineering/production-system-design-capstone](https://coderssecret.com/courses/distributed-systems-engineering/production-system-design-capstone)

## Labs

| # | Lab | Difficulty | Time |
|---|---|---|---|
| 12.1 | [Multi-Region Active-Active Demo](lab-multi-region/) | Advanced | 120 min |
| 12.2 | [DR Drill](lab-dr-drill/) | Advanced | 120 min |
| 12.3 | [Capstone Architecture Document](lab-capstone/) | Advanced | 4 hours |

## Prerequisites

- Two kind clusters (Labs 12.1 & 12.2)
- kubectl, helm
- Markdown editor for the capstone document
