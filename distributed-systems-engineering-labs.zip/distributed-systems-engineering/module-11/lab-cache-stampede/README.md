# Lab 11.2 — Cache Stampede on Expiry

> Cause a stampede when a hot key expires; add per-key locking; verify fix.

📚 **Course module:** [coderssecret.com/courses/distributed-systems-engineering/real-world-failure-scenarios](https://coderssecret.com/courses/distributed-systems-engineering/real-world-failure-scenarios)

**Difficulty:** Intermediate · **Time:** ~60 minutes

## Objective

Cause a stampede when a hot key expires; add per-key locking; verify fix.

## Prerequisites

See the [parent module README](../README.md#prerequisites).

## Steps

1. `docker compose up` deploys app + Redis + Postgres.
2. Identify a hot key (TTL=30s); pre-warm it.
3. Send 1000 concurrent requests right at expiry: `./stampede.sh`.
4. Observe origin meltdown (Postgres CPU spike).
5. Apply per-key Redis lock for recompute (`./apply-lock.sh`).
6. Repeat the stampede; verify single recompute under load.

## Expected output

Unprotected: many origin queries; Postgres saturates. Protected: a single recompute; waiters block briefly.

## Related

[Caching Strategies blog](https://coderssecret.com/blog/caching-strategies-production-guide)
