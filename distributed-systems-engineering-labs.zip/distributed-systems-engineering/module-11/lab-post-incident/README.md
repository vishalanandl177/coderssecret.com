# Lab 11.3 — Post-Incident Review

> Write a complete post-mortem for one of the simulated incidents above.

📚 **Course module:** [coderssecret.com/courses/distributed-systems-engineering/real-world-failure-scenarios](https://coderssecret.com/courses/distributed-systems-engineering/real-world-failure-scenarios)

**Difficulty:** Intermediate · **Time:** ~60 minutes

## Objective

Write a complete post-mortem for one of the simulated incidents above.

## Prerequisites

See the [parent module README](../README.md#prerequisites).

## Steps

1. Pick the retry-storm or cache-stampede incident.
2. Reconstruct the timeline from `docker compose logs` and any saved metrics.
3. Use the template in `POSTMORTEM_TEMPLATE.md`:
   - Timeline (minute-by-minute)
   - Impact (who/how-long/in-what-way)
   - Root cause (multiple contributing factors)
   - Detection (how was it discovered)
   - Mitigation (what stopped it)
   - Action items (assigned, deadlined, tracked)
4. Submit to peer review.

## Expected output

A complete post-mortem document with at least 3 concrete, owned, deadlined action items. Without action items the document is theatre.

## Related

[Real-World Failure Scenarios module](https://coderssecret.com/courses/distributed-systems-engineering/real-world-failure-scenarios)
