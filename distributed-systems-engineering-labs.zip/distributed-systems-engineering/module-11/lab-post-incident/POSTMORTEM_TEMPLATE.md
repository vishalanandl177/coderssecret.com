# Post-Incident Review — [Incident Title]

**Date of incident:** YYYY-MM-DD
**Author(s):** name(s)
**Status:** Draft / In Review / Final

---

## TL;DR

One paragraph: what happened, who was affected, how long, and the headline learning.

## Impact

- **Users affected:** number / percentage / segment
- **Duration:** start time → end time, with timezone
- **Business impact:** revenue, SLA breach, reputational, etc.
- **Severity:** SEV1 / SEV2 / SEV3

## Timeline

Reconstruct from logs, metrics, Slack, paging system. Be precise about times.

| Time (UTC) | Event |
|---|---|
| 14:02 | Alert fires: `payments_p99_latency > 500ms` |
| 14:03 | On-call paged |
| 14:05 | First response acknowledges |
| 14:08 | Hypothesis: downstream issuer-bank brownout |
| ... | ... |
| 14:42 | Mitigation applied (circuit breaker enabled) |
| 14:50 | Recovery confirmed via dashboards |
| 15:00 | Incident closed |

## Root cause

Multiple contributing factors usually. Don't settle for "one root cause" if the truth is more nuanced.

1. **Primary cause:** ...
2. **Contributing factor:** ...
3. **Why detection took N minutes:** ...

## What worked

- Things the team did well
- Tools that helped
- Pre-existing controls that limited blast radius

## What didn't work

- Gaps in detection
- Gaps in tooling
- Gaps in runbook
- Decisions made under stress that we'd reconsider

## Action items

The most important section. Without owned, deadlined, tracked items, the document is theatre.

| # | Action | Owner | Deadline | Status |
|---|---|---|---|---|
| 1 | Add per-vendor circuit breaker to payments client | @alice | 2026-05-15 | Open |
| 2 | Document the "issuer brownout" runbook | @bob | 2026-05-08 | Open |
| 3 | Add saturation alert on payments-svc thread pool | @carol | 2026-05-10 | Open |

## Appendix

- Related issues: #1234, #1567
- Linked dashboards: [Grafana](https://...)
- Linked traces: [Jaeger](https://...)
