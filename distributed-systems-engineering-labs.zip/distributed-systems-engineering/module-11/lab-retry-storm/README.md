# Lab 11.1 — Reproduce a Retry Storm

> Configure naive retries; cause an outage; add backoff + budget; observe recovery.

📚 **Course module:** [coderssecret.com/courses/distributed-systems-engineering/real-world-failure-scenarios](https://coderssecret.com/courses/distributed-systems-engineering/real-world-failure-scenarios)

**Difficulty:** Intermediate · **Time:** ~90 minutes

## Objective

Configure naive retries; cause an outage; add backoff + budget; observe recovery.

## Prerequisites

See the [parent module README](../README.md#prerequisites).

## Steps

1. `docker compose up` starts a 3-service chain.
2. Inject 50% errors on the bottom service: `./fault.sh inject 50%`.
3. Configure naive retries (no backoff, no budget) — observe RPS amplification on the bottom service.
4. Apply exponential backoff + jitter (`./apply-backoff.sh`) — observe partial improvement.
5. Apply retry budget (`./apply-budget.sh`) — observe full recovery.

## Expected output

Same scenario as Lab 2.2 but framed as an incident: telemetry shows the storm pattern, recovery requires the right defence layered.

## Related

[Rate Limiting Algorithms blog](https://coderssecret.com/blog/rate-limiting-algorithms-production-guide)
