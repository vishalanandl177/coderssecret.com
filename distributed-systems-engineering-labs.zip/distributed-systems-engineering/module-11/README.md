# Module 11 — Real-World Failure Scenarios

> Retry storms, cache stampedes, split brain, hot partitions, post-mortems.

📚 **Course module:** [coderssecret.com/courses/distributed-systems-engineering/real-world-failure-scenarios](https://coderssecret.com/courses/distributed-systems-engineering/real-world-failure-scenarios)

## Labs

| # | Lab | Difficulty | Time |
|---|---|---|---|
| 11.1 | [Reproduce a Retry Storm](lab-retry-storm/) | Intermediate | 90 min |
| 11.2 | [Cache Stampede on Expiry](lab-cache-stampede/) | Intermediate | 60 min |
| 11.3 | [Post-Incident Review](lab-post-incident/) | Intermediate | 60 min |

## Prerequisites

- Docker + docker-compose
- Load generator (`vegeta` or `hey`)
