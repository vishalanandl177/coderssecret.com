# Lab 6.1 — HPA on Custom Metrics

> Configure HPA based on RPS or queue depth via Prometheus Adapter; observe scale-up under load.

📚 **Course module:** [coderssecret.com/courses/distributed-systems-engineering/scalability-engineering](https://coderssecret.com/courses/distributed-systems-engineering/scalability-engineering)

**Difficulty:** Intermediate · **Time:** ~90 minutes

## Objective

Configure HPA based on RPS or queue depth via Prometheus Adapter; observe scale-up under load.

## Prerequisites

See the [parent module README](../README.md#prerequisites).

## Steps

1. `kind create cluster --name dse-hpa`.
2. `helm install` Prometheus + Prometheus Adapter (manifests in `charts/`).
3. Deploy app + ServiceMonitor + HPA pinned to `http_requests_per_second`.
4. Generate load: `hey -z 5m -q 200 http://localhost/api`.
5. Watch `kubectl get hpa` and `kubectl get pods -w`; replicas scale up.
6. Cool down; watch scale down (slower default to avoid flapping).

## Expected output

Replicas scale from 1 → ~6 within 1-2 min of load start; scale back to 1 ~5 min after load ends.

## Related

[Scalability Engineering module](https://coderssecret.com/courses/distributed-systems-engineering/scalability-engineering)
