# Lab 6.2 — Cache-Aside with Stampede Protection

> Implement cache-aside with per-key locking to prevent thundering herd.

📚 **Course module:** [coderssecret.com/courses/distributed-systems-engineering/scalability-engineering](https://coderssecret.com/courses/distributed-systems-engineering/scalability-engineering)

**Difficulty:** Intermediate · **Time:** ~60 minutes

## Objective

Implement cache-aside with per-key locking to prevent thundering herd.

## Prerequisites

See the [parent module README](../README.md#prerequisites).

## Steps

1. `docker compose up` starts the demo app + Redis + Postgres.
2. Run `python naive-cache-aside.py` and force a stampede via `vegeta -rate=500 -duration=10s` against an expired key.
3. Observe Postgres connection saturation and origin meltdown.
4. Switch to `python lock-on-miss.py` (per-key Redis lock for recompute).
5. Repeat the load — verify only one origin call per cache miss.

## Expected output

Naive: many concurrent origin queries; Postgres CPU spikes. Lock-on-miss: a single recompute per key; latency is briefly elevated for waiters but origin is protected.

## Related

[Caching Strategies blog](https://coderssecret.com/blog/caching-strategies-production-guide)
