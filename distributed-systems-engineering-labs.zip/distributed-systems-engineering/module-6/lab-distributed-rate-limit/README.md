# Lab 6.3 — Distributed Rate Limiter (Redis Lua)

> Implement an atomic token-bucket rate limiter as a Redis Lua script; load test it.

📚 **Course module:** [coderssecret.com/courses/distributed-systems-engineering/scalability-engineering](https://coderssecret.com/courses/distributed-systems-engineering/scalability-engineering)

**Difficulty:** Advanced · **Time:** ~60 minutes

## Objective

Implement an atomic token-bucket rate limiter as a Redis Lua script; load test it.

## Prerequisites

See the [parent module README](../README.md#prerequisites).

## Steps

1. `docker compose up` starts Redis Cluster + 3 gateway replicas + a load generator.
2. Inspect `scripts/token_bucket.lua` — single Lua script doing GET, refill, decrement, SET atomically.
3. Generate concurrent load from many clients across all gateway replicas.
4. Verify the global rate enforced is exactly the configured bucket capacity / refill rate.
5. Inspect Redis CPU and latency overhead.

## Expected output

Rate enforced globally even though many gateways call the script concurrently. Per-call overhead ~1-2ms p99.

## Related

[Rate Limiting Algorithms blog](https://coderssecret.com/blog/rate-limiting-algorithms-production-guide)
