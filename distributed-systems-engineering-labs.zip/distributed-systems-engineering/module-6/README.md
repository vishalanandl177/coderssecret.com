# Module 6 — Scalability Engineering

> Horizontal scaling, autoscaling, caching, rate limiting, identifying bottlenecks.

📚 **Course module:** [coderssecret.com/courses/distributed-systems-engineering/scalability-engineering](https://coderssecret.com/courses/distributed-systems-engineering/scalability-engineering)

## Labs

| # | Lab | Difficulty | Time |
|---|---|---|---|
| 6.1 | [HPA on Custom Metrics](lab-hpa-custom/) | Intermediate | 90 min |
| 6.2 | [Cache-Aside with Stampede Protection](lab-cache-stampede/) | Intermediate | 60 min |
| 6.3 | [Distributed Rate Limiter (Redis Lua)](lab-distributed-rate-limit/) | Advanced | 60 min |

## Prerequisites

- kind + kubectl + helm (for Lab 6.1)
- Docker + docker-compose (Labs 6.2, 6.3)
- A simple load-generator (`vegeta`, `hey`, or `wrk`)
