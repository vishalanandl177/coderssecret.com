# Lab 7.1 — Circuit Breaker in Action

> Implement a circuit breaker, trigger failure modes, validate state transitions.

📚 **Course module:** [coderssecret.com/courses/distributed-systems-engineering/reliability-failure-engineering](https://coderssecret.com/courses/distributed-systems-engineering/reliability-failure-engineering)

**Difficulty:** Intermediate · **Time:** ~60 minutes

## Objective

Implement a circuit breaker, trigger failure modes, validate state transitions.

## Prerequisites

See the [parent module README](../README.md#prerequisites).

## Steps

1. `docker compose up` starts the demo (Resilience4j-wrapped client + flaky downstream).
2. Inject 50% error rate (`./inject.sh 50%`); observe breaker trip from CLOSED → OPEN.
3. Wait for the configured timeout; observe HALF-OPEN; trial requests resolve back to CLOSED on success.
4. Compare with no-breaker scenario: caller threads exhaust under the same load.

## Expected output

With breaker: caller fails fast in OPEN state, recovers automatically. Without: thread pool exhaustion within 30s.

## Related

[Reliability & Failure Engineering module](https://coderssecret.com/courses/distributed-systems-engineering/reliability-failure-engineering)
