# Lab 7.3 — Graceful Degradation Architecture

> Refactor a service with multiple dependencies to degrade gracefully under partial failure.

📚 **Course module:** [coderssecret.com/courses/distributed-systems-engineering/reliability-failure-engineering](https://coderssecret.com/courses/distributed-systems-engineering/reliability-failure-engineering)

**Difficulty:** Intermediate · **Time:** ~60 minutes

## Objective

Refactor a service with multiple dependencies to degrade gracefully under partial failure.

## Prerequisites

See the [parent module README](../README.md#prerequisites).

## Steps

1. `docker compose up` starts a product service with deps: catalog (critical), recommendations (enriching), reviews (enriching).
2. Inject failures via `./inject.sh recommendations down`.
3. Verify product service returns 200 with empty recommendations (degraded but valid).
4. Inject `catalog down` — verify product service returns 503 (critical-path failure propagates).
5. Compare the structured-output and code paths.

## Expected output

Enriching deps degrade silently; critical deps fail loud. The architecture choice is documented in code, not improvised at incident time.

## Related

[Reliability & Failure Engineering module](https://coderssecret.com/courses/distributed-systems-engineering/reliability-failure-engineering)
