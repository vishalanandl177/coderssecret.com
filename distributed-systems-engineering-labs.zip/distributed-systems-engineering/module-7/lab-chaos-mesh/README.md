# Lab 7.2 — Chaos Mesh on Kubernetes

> Run chaos experiments on a kind cluster and observe how the application reacts.

📚 **Course module:** [coderssecret.com/courses/distributed-systems-engineering/reliability-failure-engineering](https://coderssecret.com/courses/distributed-systems-engineering/reliability-failure-engineering)

**Difficulty:** Advanced · **Time:** ~120 minutes

## Objective

Run chaos experiments on a kind cluster and observe how the application reacts.

## Prerequisites

See the [parent module README](../README.md#prerequisites).

## Steps

1. `kind create cluster --name dse-chaos`.
2. Install Chaos Mesh: `helm install chaos-mesh chaos-mesh/chaos-mesh -n chaos-testing --create-namespace`.
3. Deploy demo app from `manifests/`.
4. Apply `experiments/pod-kill.yaml` (pod chaos), `experiments/network-loss.yaml` (network chaos), `experiments/cpu-stress.yaml`.
5. Verify app continues to serve via `./observe.sh`. Document the chaos game-day runbook.

## Expected output

App handles pod-kill via re-scheduling, network-loss via retries, CPU stress via degradation. Where it doesn't, the experiment found a real gap.

## Related

[Reliability & Failure Engineering module](https://coderssecret.com/courses/distributed-systems-engineering/reliability-failure-engineering)
