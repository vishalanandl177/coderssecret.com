# Module 7 — Reliability & Failure Engineering

> Circuit breakers, bulkheads, graceful degradation, chaos engineering.

📚 **Course module:** [coderssecret.com/courses/distributed-systems-engineering/reliability-failure-engineering](https://coderssecret.com/courses/distributed-systems-engineering/reliability-failure-engineering)

## Labs

| # | Lab | Difficulty | Time |
|---|---|---|---|
| 7.1 | [Circuit Breaker in Action](lab-circuit-breaker/) | Intermediate | 60 min |
| 7.2 | [Chaos Mesh on Kubernetes](lab-chaos-mesh/) | Advanced | 120 min |
| 7.3 | [Graceful Degradation Architecture](lab-graceful-degradation/) | Intermediate | 60 min |

## Prerequisites

- Docker + docker-compose
- kind for Lab 7.2
- Go 1.21+ or Java 17+ (for Resilience4j in Lab 7.1)
