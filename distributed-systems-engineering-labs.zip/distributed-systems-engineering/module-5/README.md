# Module 5 — Consensus & Coordination

> Raft, Paxos, leader election, distributed locking with fencing tokens, etcd.

📚 **Course module:** [coderssecret.com/courses/distributed-systems-engineering/consensus-coordination](https://coderssecret.com/courses/distributed-systems-engineering/consensus-coordination)

## Labs

| # | Lab | Difficulty | Time |
|---|---|---|---|
| 5.1 | [etcd Cluster Bootstrap and Failover](lab-etcd-cluster/) | Intermediate | 90 min |
| 5.2 | [Distributed Lock with Fencing Token](lab-distributed-lock/) | Advanced | 90 min |
| 5.3 | [Leader Election in Application Code](lab-leader-election/) | Intermediate | 60 min |

## Prerequisites

- Docker + docker-compose
- kind (for Lab 5.3 K8s leader election)
- Go 1.21+ (preferred for etcd / Kubernetes client work)
