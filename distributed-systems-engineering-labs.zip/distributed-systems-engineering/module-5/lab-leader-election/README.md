# Lab 5.3 — Leader Election in Application Code

> Build a singleton-task pattern: many replicas, only one runs the periodic job at a time.

📚 **Course module:** [coderssecret.com/courses/distributed-systems-engineering/consensus-coordination](https://coderssecret.com/courses/distributed-systems-engineering/consensus-coordination)

**Difficulty:** Intermediate · **Time:** ~60 minutes

## Objective

Build a singleton-task pattern: many replicas, only one runs the periodic job at a time.

## Prerequisites

See the [parent module README](../README.md#prerequisites).

## Steps

1. `kind create cluster --name dse-leader` creates a kind cluster.
2. `kubectl apply -f manifests/` deploys 3 replicas of an application that uses the Kubernetes Lease API.
3. Watch logs: only one replica logs 'I am the leader, executing cron'.
4. Kill the leader pod (`kubectl delete pod <leader>`); verify another replica takes over within seconds.
5. Tear down: `kind delete cluster --name dse-leader`.

## Expected output

Exactly one replica acts as leader at any time. Failover within ~5 seconds (default lease TTL).

## Related

[Consensus & Coordination module](https://coderssecret.com/courses/distributed-systems-engineering/consensus-coordination)
