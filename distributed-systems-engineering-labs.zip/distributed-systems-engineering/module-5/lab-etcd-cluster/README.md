# Lab 5.1 — etcd Cluster Bootstrap and Failover

> Run a 3-node etcd cluster, write data, kill one node, verify availability; kill two, observe stuck quorum.

📚 **Course module:** [coderssecret.com/courses/distributed-systems-engineering/consensus-coordination](https://coderssecret.com/courses/distributed-systems-engineering/consensus-coordination)

**Difficulty:** Intermediate · **Time:** ~90 minutes

## Objective

Run a 3-node etcd cluster, write data, kill one node, verify availability; kill two, observe stuck quorum.

## Prerequisites

See the [parent module README](../README.md#prerequisites).

## Steps

1. `docker compose up` bootstraps a 3-node etcd cluster.
2. Write keys via `etcdctl put foo bar`; observe replication via `etcdctl get foo --consistency=l`.
3. Kill one node (`docker compose stop etcd-2`); verify writes still succeed.
4. Kill two nodes; verify writes block (quorum lost).
5. Restore via `scripts/restore-from-snapshot.sh`; re-add members one at a time.

## Expected output

Single-node failure: cluster keeps writing. Two-node failure: writes block. Restoration runbook works as documented.

## Related

[Consensus & Coordination module](https://coderssecret.com/courses/distributed-systems-engineering/consensus-coordination)
