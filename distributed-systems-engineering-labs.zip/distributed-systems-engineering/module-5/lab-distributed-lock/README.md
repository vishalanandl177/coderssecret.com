# Lab 5.2 — Distributed Lock with Fencing Token

> Implement a correct distributed lock using etcd Lease + fencing token; demonstrate why naive locks fail.

📚 **Course module:** [coderssecret.com/courses/distributed-systems-engineering/consensus-coordination](https://coderssecret.com/courses/distributed-systems-engineering/consensus-coordination)

**Difficulty:** Advanced · **Time:** ~90 minutes

## Objective

Implement a correct distributed lock using etcd Lease + fencing token; demonstrate why naive locks fail.

## Prerequisites

See the [parent module README](../README.md#prerequisites).

## Steps

1. `docker compose up` starts etcd + Postgres (the protected resource) + 2 client containers.
2. Run `python naive-redis-lock.py` (using a Redis SETNX lock); reproduce the partition failure mode by pausing one client (`docker compose pause client-1`).
3. Observe both clients believing they hold the lock — silent corruption in Postgres.
4. Run `python etcd-fencing-lock.py`; etcd issues a monotonic token with each acquisition.
5. Postgres rejects writes from older tokens (via the fencing trigger).
6. Demonstrate two-client race; only the higher-token operation succeeds.

## Expected output

Naive lock: silent double-write corruption. Fencing lock: stale lock holder is rejected at the resource layer; integrity preserved.

## Related

[Mastering SPIFFE & SPIRE](https://coderssecret.com/courses/mastering-spiffe-spire) for related identity primitives
